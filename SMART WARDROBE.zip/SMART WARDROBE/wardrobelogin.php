<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

$servername = "localhost";
$username = "root";
$password = "Liam5641.";
$dbname = "wardrobe_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    $location = $conn->real_escape_string($_POST['location']);

    if ($action == "signup") {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert data into the database
        $sql = "INSERT INTO logintable (username, password, location) VALUES ('$username', '$hashed_password', '$location')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>
                    alert('Signup successful! Redirecting to Event page...');
                    window.location.href = 'Event.html';
                  </script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    } elseif ($action == "login") {
        // Verify user credentials
        $sql = "SELECT password FROM logintable WHERE username='$username' AND location='$location'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Set session variable to indicate the user is logged in
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;

                echo "<script>
                        alert('Login successful! Redirecting to Event page...');
                        window.location.href = 'Event.html';
                      </script>";
            } else {
                echo "<script>alert('Invalid password.');</script>";
            }
        } else {
            echo "<script>alert('No user found with the given credentials.');</script>";
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Wardrobe System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

        <style>
        body {
            font-family: Arial, sans-serif;
            background-size: cover;
            background-position: center;
            animation: bgAnimation 15s infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        @keyframes bgAnimation {
            0% { background-image: url('image1.jpg'); }
            33% { background-image: url('image2.jpg'); }
            66% { background-image: url('image3.jpg'); }
            100% { background-image: url('image1.jpg'); }
        }
        .dropdown {
            position: absolute;
            top: 10px;
            left: 10px;
        }
        .dropdown button {
            background-color: #5cb85c;
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .dropdown button:hover {
            background-color: #4cae4c;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            position: relative;
        }
        h1 {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            text-align: left;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .fa-icon {
            margin-right: 8px;
        }
        .signup-container {
            display: none;
        }
    
    </style>
    <script>
        function showSignup() {
            document.getElementById("login-form").style.display = "none";
            document.getElementById("signup-form").style.display = "block";
        }

        function showLogin() {
            document.getElementById("login-form").style.display = "block";
            document.getElementById("signup-form").style.display = "none";
        }
        window.onload = function() {
            showLogin();
        };
    </script>
</head>
<body>
    <div class="dropdown">
        <button><i class="fas fa-bars"></i></button>
        <div class="dropdown-content">
            <a href="Event.html">Choose Event</a>
            <a href="blog.php">Blog/Resources</a>
            <a href="TrackCloth.html">Track cloth</a>
        </div>
    </div>
    <div class="login-container">
        <?php
        // Check if the user is logged in
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
            // Display a welcome message and a logout button
            echo "<h1>Welcome, " . $_SESSION['username'] . "!</h1>";
            echo "<a href='logout.php'><button><i class='fas fa-sign-out-alt fa-icon'></i>Logout</button></a>";
        } else {
            // Display the login/signup forms
            echo '
            <h1>Members Login</h1>
            <div id="login-form">
                <form action="login.php" method="POST">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                    <label for="location">Location</label>
                    <input type="text" id="location" name="location" required>
                    <input type="hidden" name="action" value="login">
                    <button type="submit"><i class="fas fa-sign-in-alt fa-icon"></i>Login</button>
                </form>
                <button onclick="showSignup()"><i class="fas fa-user-plus fa-icon"></i>Signup</button>
            </div>
            <div id="signup-form" class="signup-container">
                <form action="login.php" method="POST">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                    <label for="location">Location</label>
                    <input type="text" id="location" name="location" required>
                    <input type="hidden" name="action" value="signup">
                    <button type="submit"><i class="fas fa-user-plus fa-icon"></i>Signup</button>
                </form>
                <button onclick="showLogin()"><i class="fas fa-sign-in-alt fa-icon"></i>Back to Login</button>
            </div>';
        }
        ?>
    </div>
</body>
</html>



