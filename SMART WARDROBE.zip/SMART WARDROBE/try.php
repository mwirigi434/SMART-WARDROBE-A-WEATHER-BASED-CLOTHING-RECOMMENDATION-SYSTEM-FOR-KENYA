<?php
// Your API response (simulated for example)
$apiResponse = '{
    "final_result": [
        {
            "index": 1,
            "nsfw": false,
            "origin": "https://pub-static.aiease.ai/cf/2025/06/16/origin/aiease_art_v1_9126321f-db80-4aff-9203-6f0cdb95b9cb_1.webp",
            "thumb": "https://pub-static.aiease.ai/cf/2025/06/16/origin/aiease_art_v1_9126321f-db80-4aff-9203-6f0cdb95b9cb_1.webp"
        },
        {
            "index": 2,
            "nsfw": false,
            "origin": "https://pub-static.aiease.ai/cf/2025/06/16/origin/aiease_art_v1_9126321f-db80-4aff-9203-6f0cdb95b9cb_2.webp",
            "thumb": "https://pub-static.aiease.ai/cf/2025/06/16/origin/aiease_art_v1_9126321f-db80-4aff-9203-6f0cdb95b9cb_2.webp"
        }
    ]
}';

// Decode JSON into a PHP array
$result = json_decode($apiResponse, true);

// Check if decoding was successful
if ($result && isset($result['final_result'])) {
    echo "<h2>Generated Images:</h2>";
    echo "<div style='display: flex; gap: 20px;'>";
    
    foreach ($result['final_result'] as $image) {
        echo "<div>";
        echo "<img src='{$image['origin']}' alt='AI Generated Image' style='width: 300px; height: auto;' />";
        echo "<p>Image #{$image['index']}</p>";
        echo "</div>";
    }
    
    echo "</div>";
} else {
    echo "Error: Could not decode API response or no images found.";
}
?>