<?php
// Get the clothing recommendations from our API
$recommendationsJson = file_get_contents('http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/callAI.php');
$recommendationsData = json_decode($recommendationsJson, true);

// If we couldn't fetch data, show an error
if (!$recommendationsData || $recommendationsData['status'] !== 'success') {
    die('Could not fetch clothing recommendations');
}

// Improved function to extract and format gender recommendations with occasion headers
function formatGenderRecommendations($text, $gender) {
    // Normalize the text
    $text = str_replace("\r", "", $text);
    $lines = explode("\n", $text);
    
    $found = false;
    $content = "";
    $output = "";
    $currentOccasion = "";
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        // Look for gender heading
        if (strpos(strtolower($line), strtolower("$gender clothing recommendations")) !== false) {
            $found = true;
            continue;
        }
        
        // If we found our section, collect content until next section
        if ($found) {
            // Stop if we hit another section
            if (preg_match('/^(male|female|children) clothing recommendations/i', $line)) {
                break;
            }
            
            // Detect occasion headers (Casual/Formal)
            if (preg_match('/^(Casual|Formal):/i', $line, $matches)) {
                $currentOccasion = $matches[1];
                $output .= "<div class='occasion-header'><strong>{$currentOccasion} Wear:</strong></div>";
                continue;
            }
            
            // Skip empty lines at start
            if ($content === "" && $line === "") continue;
            
            // Format bullet points and line breaks
            if (preg_match('/^[-•]/', $line)) {
                $output .= "<div class='recommendation-item'><i class='fas fa-circle-notch'></i> " . 
                           substr($line, 1) . "</div>";
            } elseif (!empty($line)) {
                $output .= "<div class='recommendation-line'>$line</div>";
            }
        }
    }
    
    return $output ?: "<div class='no-recommendations'>No $gender recommendations available</div>";
}

// Function to get weather icon based on conditions
function getWeatherIcon($description) {
    $description = strtolower($description);
    if (strpos($description, 'sun') !== false || strpos($description, 'clear') !== false) {
        return 'fa-sun';
    } elseif (strpos($description, 'rain') !== false) {
        return 'fa-cloud-rain';
    } elseif (strpos($description, 'cloud') !== false) {
        return 'fa-cloud';
    } elseif (strpos($description, 'thunder') !== false || strpos($description, 'storm') !== false) {
        return 'fa-bolt';
    } else {
        return 'fa-cloud-sun';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kenya Weather Clothing Recommendations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --male-color: #4a89dc;
            --female-color: #e667af;
            --children-color: #5d9cec;
            --weather-color: #3a7bd5;
            --link-color: #6c5ce7;
            --box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            --box-shadow-hover: 0 8px 25px rgba(0,0,0,0.12);
            --casual-color: #00b894;
            --formal-color: #6c5ce7;
        }
        body {
            background: #f8f9fa;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
            line-height: 1.6;
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 20px 0;
        }
        .header h1 {
            color: #3a7bd5;
            font-weight: 700;
            font-size: 2.5rem;
            margin-bottom: 10px;
            background: linear-gradient(to right, #3a7bd5, #00d2ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .header p {
            color: #6c757d;
            font-size: 1.1rem;
            max-width: 700px;
            margin: 0 auto;
        }
        .main-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .weather-container {
            max-width: 800px;
            margin: 0 0 40px 0; /* Removed auto margin to align left */
        }
        .recommendation-container {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
            margin-bottom: 40px;
        }
        .recommendation-box {
            background: white;
            border-radius: 15px;
            box-shadow: var(--box-shadow);
            padding: 30px;
            width: 100%;
            max-width: 350px;
            border-top: 5px solid;
            transition: all 0.3s ease;
        }
        .recommendation-box:hover {
            transform: translateY(-5px);
            box-shadow: var(--box-shadow-hover);
        }
        .male-box {
            border-top-color: var(--male-color);
        }
        .female-box {
            border-top-color: var(--female-color);
        }
        .children-box {
            border-top-color: var(--children-color);
        }
        .weather-box {
            border-top-color: var(--weather-color);
            width: 100%;
        }
        .links-box {
            border-top-color: var(--link-color);
            max-width: 800px;
            margin: 40px auto;
            text-align: center;
        }
        .box-title {
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            color: #2c3e50;
            font-size: 1.3rem;
        }
        .box-title i {
            margin-right: 15px;
            font-size: 1.5rem;
        }
        .weather-box .box-title i {
            color: var(--weather-color);
        }
        .male-box .box-title i {
            color: var(--male-color);
        }
        .female-box .box-title i {
            color: var(--female-color);
        }
        .children-box .box-title i {
            color: var(--children-color);
        }
        .links-box .box-title i {
            color: var(--link-color);
        }
        .recommendation-content {
            color: #495057;
        }
        .occasion-header {
            font-weight: 600;
            margin: 20px 0 10px 0;
            padding-bottom: 5px;
            border-bottom: 2px solid #eee;
        }
        .occasion-header.casual {
            color: var(--casual-color);
            border-bottom-color: var(--casual-color);
        }
        .occasion-header.formal {
            color: var(--formal-color);
            border-bottom-color: var(--formal-color);
        }
        .recommendation-item {
            margin-bottom: 12px;
            padding-left: 15px;
            border-left: 3px solid #eee;
            transition: all 0.3s ease;
        }
        .recommendation-item:hover {
            border-left-color: var(--male-color);
        }
        .female-box .recommendation-item:hover {
            border-left-color: var(--female-color);
        }
        .children-box .recommendation-item:hover {
            border-left-color: var(--children-color);
        }
        .recommendation-item i {
            color: #adb5bd;
            font-size: 0.7rem;
            margin-right: 12px;
            transition: all 0.3s ease;
        }
        .recommendation-item:hover i {
            color: inherit;
        }
        .recommendation-line {
            margin-bottom: 12px;
        }
        .no-recommendations {
            color: #6c757d;
            font-style: italic;
        }
        .weather-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f1f1f1;
            transition: all 0.3s ease;
        }
        .weather-item:hover {
            background: rgba(0,0,0,0.02);
            border-radius: 8px;
        }
        .weather-item:last-child {
            border-bottom: none;
        }
        .weather-icon {
            font-size: 1.8rem;
            width: 50px;
            text-align: center;
            margin-right: 20px;
            color: var(--weather-color);
        }
        .weather-details {
            flex-grow: 1;
        }
        .city-name {
            font-weight: 600;
            margin-bottom: 5px;
            font-size: 1.1rem;
        }
        .weather-stats {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 0.95rem;
        }
        .weather-stat {
            display: flex;
            align-items: center;
        }
        .weather-stat i {
            margin-right: 8px;
            color: #6c757d;
            font-size: 0.9rem;
        }
        .link-section {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 20px;
        }
        .custom-link {
            display: inline-block;
            padding: 12px 20px;
            background: linear-gradient(to right, var(--link-color), #a29bfe);
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }
        .custom-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(108, 92, 231, 0.3);
            color: white;
        }
        .custom-link i {
            margin-right: 8px;
        }
        .footer {
            text-align: center;
            margin-top: 60px;
            color: #6c757d;
            font-size: 0.95rem;
            padding: 20px 0;
            border-top: 1px solid #eee;
        }
        @media (max-width: 768px) {
            .header h1 {
                font-size: 2rem;
            }
            .recommendation-container {
                flex-direction: column;
                align-items: center;
            }
            .recommendation-box {
                max-width: 100%;
            }
            .weather-item {
                flex-direction: column;
                text-align: center;
            }
            .weather-icon {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="header">
            <h1><i class="fas fa-tshirt"></i> Kenya Weather Clothing Recommendations</h1>
            <p>Smart clothing suggestions tailored to current weather conditions across Kenya</p>
        </div>

        <!-- Weather Information Box - Now aligned to left -->
        <div class="weather-container">
            <div class="recommendation-box weather-box">
                <div class="box-title">
                    <i class="fas <?php echo getWeatherIcon($recommendationsData['raw_weather_data'][array_key_first($recommendationsData['raw_weather_data'])]['description'] ?? ''); ?>"></i>
                    <h3>Current Weather Conditions</h3>
                </div>
                <div class="recommendation-content">
                    <?php foreach ($recommendationsData['raw_weather_data'] as $city => $data): ?>
                        <?php if (!isset($data['error'])): ?>
                            <div class="weather-item">
                                <div class="weather-icon">
                                    <i class="fas <?php echo getWeatherIcon($data['description']); ?>"></i>
                                </div>
                                <div class="weather-details">
                                    <div class="city-name"><?php echo htmlspecialchars($city); ?></div>
                                    <div class="weather-stats">
                                        <div class="weather-stat">
                                            <i class="fas fa-temperature-high"></i>
                                            <?php echo round($data['temperature']); ?>°C
                                        </div>
                                        <div class="weather-stat">
                                            <i class="fas fa-temperature-low"></i>
                                            Feels like <?php echo round($data['feels_like']); ?>°C
                                        </div>
                                        <div class="weather-stat">
                                            <i class="fas fa-tint"></i>
                                            <?php echo $data['humidity']; ?>% humidity
                                        </div>
                                        <div class="weather-stat">
                                            <i class="fas fa-wind"></i>
                                            <?php echo $data['wind_speed']; ?> m/s wind
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Gender Recommendation Boxes with Occasion Headers -->
        <div class="recommendation-container">
            <!-- Male Recommendations -->
            <div class="recommendation-box male-box">
                <div class="box-title">
                    <i class="fas fa-male"></i>
                    <h3>Male Clothing</h3>
                </div>
                <div class="recommendation-content">
                    <?php echo formatGenderRecommendations($recommendationsData['recommendations'], 'male'); ?>
                </div>
            </div>

            <!-- Female Recommendations -->
            <div class="recommendation-box female-box">
                <div class="box-title">
                    <i class="fas fa-female"></i>
                    <h3>Female Clothing</h3>
                </div>
                <div class="recommendation-content">
                    <?php echo formatGenderRecommendations($recommendationsData['recommendations'], 'female'); ?>
                </div>
            </div>

            <!-- Children Recommendations -->
            <div class="recommendation-box children-box">
                <div class="box-title">
                    <i class="fas fa-child"></i>
                    <h3>Children Clothing</h3>
                </div>
                <div class="recommendation-content">
                    <?php echo formatGenderRecommendations($recommendationsData['recommendations'], 'children'); ?>
                </div>
            </div>
        </div>

        <!-- Links Section -->
        <div class="recommendation-box links-box">
            <div class="box-title">
                <i class="fas fa-link"></i>
                <h3>Useful Links</h3>
            </div>
            <div class="recommendation-content">
                <p>Explore more weather and fashion resources:</p>
                <div class="link-section">
                    <!-- Example links - replace with your actual links -->
                    <a href="https://example.com/weather" class="custom-link" target="_blank">
                        <i class="fas fa-cloud-sun"></i> Kenya Weather Forecast
                    </a>
                    <a href="https://example.com/fashion-tips" class="custom-link" target="_blank">
                        <i class="fas fa-tshirt"></i> Seasonal Fashion Guide
                    </a>
                    <a href="https://example.com/emergency" class="custom-link" target="_blank">
                        <i class="fas fa-exclamation-triangle"></i> Weather Emergency Info
                    </a>
                </div>
            </div>
        </div>

        <div class="footer">
            <p><i class="fas fa-clock"></i> Last updated: <?php echo htmlspecialchars($recommendationsData['last_updated']); ?></p>
            <p>&copy; <?php echo date('Y'); ?> Kenya Weather Fashion Advisor | All Rights Reserved</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>