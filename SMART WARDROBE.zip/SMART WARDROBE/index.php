<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

    <!-- Custom CSS -->
    <style>
        /* Set the background image */
        body {
            background-image: url('images/background.jpg'); /* Replace with your image path */
            background-size: cover; /* Cover the entire screen */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent repeating */
            background-attachment: fixed; /* Fix the background while scrolling */
            min-height: 100vh; /* Ensure the body covers the full viewport height */
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Navbar styling */
        .navbar-section {
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            backdrop-filter: blur(10px); /* Add a blur effect */
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }

        .nav-link {
            font-weight: 500;
            margin-left: 15px;
        }

        /* Hero section styling */
        .hero-section {
            padding: 100px 0;
            color: #fff; /* White text for better contrast */
        }

        .hero-section .text-content {
            background-color: rgba(0, 0, 0, 0.6); /* Semi-transparent black background */
            padding: 20px;
            border-radius: 10px;
        }

        .hero-section .btn {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 20px;
        }

        .hero-section .btn:hover {
            background-color: #0056b3;
        }

        .hero-section img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
    </style>
</head>

<body>

    <!-- Navbar Section -->
    <header class="navbar-section">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><i class="bi bi-chat"></i> Smart Wardrobe</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#home">Home</a>
                        </li>
                      <!--  <li class="nav-item">
                            <a class="nav-link" href="gallary_view.php">Wardrobe Gallery</a>
                        </li>-->
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signup.php">Signup</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 text-content">
                    <h1>Welcome to Smart Wardrobe</h1>
                    <p>Smart Wardrobe empowers you to organize your clothing, plan your outfits, and track your style preferences effortlessly. Simply upload your wardrobe, mix and match pieces, and discover personalized outfit suggestions for every occasion.</p>
                    <button class="btn"><a href="blog.html" style="color: #fff; text-decoration: none;">Click Here</a></button>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <img src="images/hero-image.png" alt="Smart Wardrobe" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
</body>

</html>