<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Function to generate better prompts from recommendations
function generateFashionPrompt($gender, $recommendations) {
    $prompts = [
        'male' => "A stylish Kenyan man in his 30s wearing $recommendations. Full body shot, photorealistic, studio lighting, clean background, fashion magazine style",
        'female' => "An elegant Kenyan woman in her 30s wearing $recommendations. Full body shot, high fashion, detailed fabric textures, professional photography",
        'children' => "A cute Kenyan child wearing $recommendations. Playful pose, bright colors, soft lighting, commercial kids fashion style"
    ];
    return $prompts[$gender] ?? "Kenyan $gender fashion: $recommendations";
}

// Sample data when API fails
$sampleData = [
    'recommendations' => "Light clothing for warm weather: linen shirts, shorts, and sandals for men; sundresses and wide-brim hats for women; breathable cotton outfits for children",
    'status' => 'success'
];

try {
    // Try to get real recommendations
    $weatherData = @json_decode(file_get_contents('callAI.php'), true) ?: $sampleData;
    
    if (!isset($weatherData['status']) || $weatherData['status'] !== 'success') {
        throw new Exception("API returned error status");
    }
    
    $recommendations = $weatherData['recommendations'] ?? $sampleData['recommendations'];
    $hasRecommendations = true;
    
} catch (Exception $e) {
    $recommendations = $sampleData['recommendations'];
    $hasRecommendations = false;
}

// All possible image options for each category with verified working links
$allImageOptions = [
    'male' => [
        'https://images.unsplash.com/photo-1520367445093-50dc08a59d9d?w=600&auto=format',
        'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format',
        'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=600&auto=format',
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format',
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&auto=format',
        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&auto=format'
    ],
    'female' => [
        'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=600&auto=format',
        'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&auto=format',
        'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format',
        'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600&auto=format',
        'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=600&auto=format',
        'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=600&auto=format'
    ],
    'children' => [
        'https://images.unsplash.com/photo-1604917018618-597b68a87bda?w=600&auto=format',
        'https://images.unsplash.com/photo-1519311965067-36d3e5f33d39?w=600&auto=format',
        'https://images.unsplash.com/photo-1523875194681-bedd468c58bf?w=600&auto=format',
        'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=600&auto=format',
        'https://images.unsplash.com/photo-1523878288860-6f3105469a14?w=600&auto=format',
        'https://images.unsplash.com/photo-1519683109079-d5f539e1542f?w=600&auto=format'
    ]
];

// Outfit details for all possible images
$allOutfitDetails = [
    'male' => [
        ['top' => 'Linen shirt', 'bottom' => 'Khaki shorts', 'footwear' => 'Leather sandals', 'accessories' => 'Sunglasses and wristwatch'],
        ['top' => 'Polo shirt', 'bottom' => 'Chino pants', 'footwear' => 'Loafers', 'accessories' => 'Leather belt'],
        ['top' => 'Short-sleeve button-down', 'bottom' => 'Denim jeans', 'footwear' => 'Canvas shoes', 'accessories' => 'Baseball cap'],
        ['top' => 'T-shirt', 'bottom' => 'Cargo pants', 'footwear' => 'Hiking boots', 'accessories' => 'Backpack'],
        ['top' => 'Sweater', 'bottom' => 'Dress pants', 'footwear' => 'Dress shoes', 'accessories' => 'Watch'],
        ['top' => 'Hoodie', 'bottom' => 'Joggers', 'footwear' => 'Sneakers', 'accessories' => 'Beanie']
    ],
    'female' => [
        ['top' => 'Floral sundress', 'bottom' => '', 'footwear' => 'Strappy sandals', 'accessories' => 'Wide-brim hat and tote bag'],
        ['top' => 'Blouse', 'bottom' => 'Midi skirt', 'footwear' => 'Block heels', 'accessories' => 'Statement necklace'],
        ['top' => 'Crop top', 'bottom' => 'High-waisted shorts', 'footwear' => 'Espadrilles', 'accessories' => 'Hoops and bracelet'],
        ['top' => 'Turtleneck', 'bottom' => 'Pencil skirt', 'footwear' => 'Ankle boots', 'accessories' => 'Scarf'],
        ['top' => 'Tank top', 'bottom' => 'Maxi skirt', 'footwear' => 'Wedges', 'accessories' => 'Sunhat'],
        ['top' => 'Sweater', 'bottom' => 'Leggings', 'footwear' => 'Boots', 'accessories' => 'Infinity scarf']
    ],
    'children' => [
        ['top' => 'Colorful t-shirt', 'bottom' => 'Denim shorts', 'footwear' => 'Sneakers', 'accessories' => 'Baseball cap'],
        ['top' => 'Polo shirt', 'bottom' => 'Cargo shorts', 'footwear' => 'Sandals', 'accessories' => 'Sunglasses'],
        ['top' => 'T-shirt', 'bottom' => 'Swim trunks', 'footwear' => 'Flip flops', 'accessories' => 'Water bottle'],
        ['top' => 'Hoodie', 'bottom' => 'Jeans', 'footwear' => 'Sneakers', 'accessories' => 'Backpack'],
        ['top' => 'Dress shirt', 'bottom' => 'Khakis', 'footwear' => 'Loafers', 'accessories' => 'Watch'],
        ['top' => 'Rain jacket', 'bottom' => 'Waterproof pants', 'footwear' => 'Rain boots', 'accessories' => 'Umbrella']
    ]
];

// Function to get random unique images (3 per category)
function getRandomImages($allOptions, $allDetails, $gender) {
    $keys = array_rand($allOptions[$gender], 3); // Get 3 random keys
    $images = [];
    $details = [];
    
    foreach ($keys as $key) {
        $images[] = $allOptions[$gender][$key];
        $details[] = $allDetails[$gender][$key];
    }
    
    return ['images' => $images, 'details' => $details];
}

// Generate new images on each page load
$imageOptions = [];
$outfitDetails = [];

foreach (['male', 'female', 'children'] as $gender) {
    $result = getRandomImages($allImageOptions, $allOutfitDetails, $gender);
    $imageOptions[$gender] = $result['images'];
    $outfitDetails[$gender] = $result['details'];
}

// Function to display images with error handling
function displayImage($url, $alt, $class) {
    echo '<img src="'.$url.'" alt="'.$alt.'" class="'.$class.'" onerror="this.onerror=null;this.src=\'https://via.placeholder.com/600x400?text=Fashion+Image+Not+Found\';">';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather Fashion Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        .navbar {
            background-color: #2c3e50;
            padding: 15px 30px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-weight: 600;
            font-size: 1.2rem;
        }
        .nav-links {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-item {
            margin-left: 15px;
        }
        .nav-link {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
        }
        .nav-link:hover {
            background-color: #34495e;
        }
        .nav-link.active {
            background-color: #3498db;
        }
        .nav-link i {
            margin-right: 8px;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }
        .recommendations {
            background-color: #f1f8fe;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border-left: 4px solid #3498db;
        }
        .fashion-category {
            margin-bottom: 40px;
        }
        .category-title {
            font-size: 24px;
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }
        .fashion-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }
        .fashion-card {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            background: white;
            position: relative;
        }
        .fashion-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .fashion-image {
            width: 100%;
            height: 350px;
            object-fit: cover;
            object-position: top center;
            border-radius: 8px 8px 0 0;
            background-color: #f5f5f5;
        }
        .image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.6);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            padding: 20px;
            text-align: center;
        }
        .fashion-card:hover .image-overlay {
            opacity: 1;
        }
        .card-body {
            padding: 20px;
        }
        .outfit-details {
            margin-top: 15px;
            font-size: 14px;
        }
        .outfit-details ul {
            list-style-type: none;
            padding: 0;
            margin: 10px 0;
        }
        .outfit-details li {
            margin-bottom: 5px;
            padding: 5px 0;
            border-bottom: 1px solid #eee;
        }
        .outfit-details li:last-child {
            border-bottom: none;
        }
        .outfit-details strong {
            color: #2c3e50;
        }
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .btn {
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            font-weight: 500;
            transition: all 0.2s;
        }
        .download-btn {
            background: #2ecc71;
            color: white;
        }
        .download-btn:hover {
            background: #27ae60;
        }
        .view-btn {
            background: #3498db;
            color: white;
        }
        .view-btn:hover {
            background: #2980b9;
        }
        .sample-notice {
            font-style: italic;
            color: #7f8c8d;
            margin-top: 10px;
        }
        #imageModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            max-width: 90%;
            max-height: 90%;
        }
        .close-modal {
            position: absolute;
            top: 20px;
            right: 30px;
            color: white;
            font-size: 30px;
            cursor: pointer;
        }
        .refresh-btn {
            background: #9b59b6;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            margin-top: 20px;
            transition: background 0.3s;
        }
        .refresh-btn:hover {
            background: #8e44ad;
        }
        .refresh-container {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="navbar-brand">Weather Fashion Generator</div>
        <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link active" href="search.php"><i class="fas fa-cloud-sun"></i> Weather</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" id="clothTab"><i class="fas fa-tshirt"></i> Cloth</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php"><i class="fas fa-user"></i> Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </div>

    <div class="container">
        <h1>Weather-Appropriate Fashion Generator</h1>
        
        <div class="recommendations">
            <h3>Today's Fashion Recommendations:</h3>
            <p><?php echo nl2br(htmlspecialchars($recommendations)); ?></p>
            <?php if (!$hasRecommendations): ?>
                <p class="sample-notice">Showing sample recommendations as weather service is unavailable</p>
            <?php endif; ?>
        </div>
        
        <?php foreach (['male', 'female', 'children'] as $gender): ?>
            <div class="fashion-category">
                <h2 class="category-title"><?php echo ucfirst($gender); ?> Fashion Options</h2>
                <div class="fashion-grid">
                    <?php foreach ($imageOptions[$gender] as $index => $imageUrl): ?>
                        <div class="fashion-card">
                            <?php displayImage(
                                $imageUrl,
                                ucfirst($gender).' fashion option '.($index + 1),
                                'fashion-image'
                            ); ?>
                            <div class="image-overlay">
                                <h3>Option <?php echo $index + 1; ?></h3>
                                <div class="btn-group">
                                    <button class="btn view-btn" 
                                            onclick="showImageDetail('<?php echo $imageUrl; ?>')">
                                        View Larger
                                    </button>
                                    <button class="btn download-btn" 
                                            onclick="downloadImage('<?php echo $imageUrl; ?>', '<?php echo $gender; ?>-fashion-<?php echo $index + 1; ?>', '<?php echo addslashes($recommendations); ?>')">
                                        Download
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <h3><?php echo ucfirst($gender); ?> Style #<?php echo $index + 1; ?></h3>
                                <div class="outfit-details">
                                    <h4>Outfit Details</h4>
                                    <ul>
                                        <?php foreach ($outfitDetails[$gender][$index] as $key => $value): ?>
                                            <?php if (!empty($value)): ?>
                                                <li><strong><?php echo ucfirst($key); ?>:</strong> <?php echo htmlspecialchars($value); ?></li>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
        
        <div class="refresh-container">
            <button class="refresh-btn" onclick="window.location.reload()">
                <i class="fas fa-sync-alt"></i> Generate New Outfits
            </button>
        </div>
    </div>

    <!-- Image Modal -->
    <div id="imageModal">
        <span class="close-modal" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <script>
        // Show image in modal
        function showImageDetail(imageUrl) {
            const modal = document.getElementById('imageModal');
            const modalImg = document.getElementById('modalImage');
            modal.style.display = 'flex';
            modalImg.src = imageUrl;
        }
        
        // Close modal
        function closeModal() {
            document.getElementById('imageModal').style.display = 'none';
        }
        
        // Close modal when clicking outside image
        window.onclick = function(event) {
            if (event.target == document.getElementById('imageModal')) {
                closeModal();
            }
        }
        
        // Enhanced download function with outfit details
        function downloadImage(url, filename, recommendations) {
            fetch(url)
                .then(response => response.blob())
                .then(blob => {
                    // Create canvas to add text
                    const img = new Image();
                    img.src = URL.createObjectURL(blob);
                    
                    img.onload = function() {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        
                        // Set canvas size (image width + padding)
                        canvas.width = img.width;
                        canvas.height = img.height + 120; // Space for text
                        
                        // Fill background
                        ctx.fillStyle = 'white';
                        ctx.fillRect(0, 0, canvas.width, canvas.height);
                        
                        // Draw image
                        ctx.drawImage(img, 0, 0, img.width, img.height);
                        
                        // Add text
                        ctx.fillStyle = 'black';
                        ctx.font = '18px Poppins';
                        
                        // Add title
                        ctx.fillText('Weather-Appropriate Fashion Recommendation', 20, img.height + 30);
                        
                        // Add recommendations (split into multiple lines if needed)
                        const maxLineWidth = canvas.width - 40;
                        const lineHeight = 24;
                        let yPosition = img.height + 60;
                        
                        // Split recommendations into lines
                        const words = recommendations.split(' ');
                        let line = '';
                        
                        for (let i = 0; i < words.length; i++) {
                            const testLine = line + words[i] + ' ';
                            const metrics = ctx.measureText(testLine);
                            const testWidth = metrics.width;
                            
                            if (testWidth > maxLineWidth && i > 0) {
                                ctx.fillText(line, 20, yPosition);
                                line = words[i] + ' ';
                                yPosition += lineHeight;
                            } else {
                                line = testLine;
                            }
                        }
                        ctx.fillText(line, 20, yPosition);
                        
                        // Add watermark
                        ctx.font = '14px Poppins';
                        ctx.fillStyle = '#7f8c8d';
                        ctx.fillText('Generated by Weather Fashion Generator', 20, canvas.height - 20);
                        
                        // Trigger download
                        const link = document.createElement('a');
                        link.href = canvas.toDataURL('image/jpeg', 0.9);
                        link.download = filename + '.jpg';
                        link.click();
                    };
                })
                .catch(error => {
                    console.error('Download error:', error);
                    // Fallback to simple download if canvas fails
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = filename + '.jpg';
                    link.click();
                });
        }
        
        // Handle cloth tab click
        document.getElementById('clothTab').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('.fashion-category:first-child').scrollIntoView({
                behavior: 'smooth'
            });
        });
    </script>
</body>
</html>