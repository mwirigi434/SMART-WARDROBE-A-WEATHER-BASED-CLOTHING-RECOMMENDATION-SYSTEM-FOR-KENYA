<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include "connection.php";

$user_id = $_SESSION['id'];  // Changed from user_id to id
$error = '';
$success = '';

// Fetch current user data
$sql = "SELECT email FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_email'])) {
        $new_email = trim($_POST['new_email']);
        $current_password = $_POST['current_password'];
        
        if (empty($new_email) || empty($current_password)) {
            $error = "All fields are required!";
        } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format!";
        } else {
            // Verify current password
            $sql = "SELECT password FROM users WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $user_data = mysqli_fetch_assoc($result);
            
            if ($current_password === $user_data['password']) {
                // Check if new email already exists
                $check_sql = "SELECT id FROM users WHERE email = ? AND id != ?";
                $stmt = mysqli_prepare($conn, $check_sql);
                mysqli_stmt_bind_param($stmt, "si", $new_email, $user_id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                
                if (mysqli_num_rows($result) > 0) {
                    $error = "Email already in use by another account!";
                } else {
                    // Update email
                    $update_sql = "UPDATE users SET email = ? WHERE id = ?";
                    $stmt = mysqli_prepare($conn, $update_sql);
                    mysqli_stmt_bind_param($stmt, "si", $new_email, $user_id);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        $success = "Email updated successfully!";
                        $user['email'] = $new_email; // Update displayed email
                    } else {
                        $error = "Error updating email: " . mysqli_error($conn);
                    }
                }
            } else {
                $error = "Current password is incorrect!";
            }
        }
    }

    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = "All fields are required!";
        } elseif ($new_password !== $confirm_password) {
            $error = "New passwords don't match!";
        } elseif (strlen($new_password) < 6) {
            $error = "Password must be at least 6 characters!";
        } else {
            // Verify current password
            $sql = "SELECT password FROM users WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $user_data = mysqli_fetch_assoc($result);
            
            if ($current_password === $user_data['password']) {
                // Update password (plain text)
                $update_sql = "UPDATE users SET password = ? WHERE id = ?";
                $stmt = mysqli_prepare($conn, $update_sql);
                mysqli_stmt_bind_param($stmt, "si", $new_password, $user_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    $success = "Password updated successfully!";
                } else {
                    $error = "Error updating password: " . mysqli_error($conn);
                }
            } else {
                $error = "Current password is incorrect!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3a0ca3;
            --success: #4cc9f0;
            --danger: #f72585;
            --light: #f8f9fa;
            --dark: #212529;
            --gradient: linear-gradient(135deg, var(--primary), var(--secondary));
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f7ff;
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            padding: 20px;
            background-image: radial-gradient(circle at 10% 20%, rgba(67, 97, 238, 0.1) 0%, rgba(58, 12, 163, 0.1) 90%);
        }

        .user-greeting {
            max-width: 900px;
            margin: 0 auto 20px;
            padding: 15px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .user-greeting h4 {
            margin-bottom: 10px;
            color: var(--dark);
        }

        .nav-tabs {
            display: flex;
            gap: 10px;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .nav-item {
            display: inline-block;
        }

        .nav-link {
            display: block;
            padding: 8px 15px;
            text-decoration: none;
            color: var(--dark);
            border-radius: 5px;
            transition: all 0.3s;
        }

        .nav-link:hover {
            background-color: rgba(67, 97, 238, 0.1);
            color: var(--primary);
        }

        .nav-link.active {
            background-color: var(--primary);
            color: white;
        }

        .nav-link i {
            margin-right: 5px;
        }
        
        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .profile-box {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(67, 97, 238, 0.15);
            padding: 40px;
            overflow: hidden;
            position: relative;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .profile-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(67, 97, 238, 0.2);
        }
        
        .profile-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: var(--gradient);
        }
        
        header {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 25px;
            color: var(--secondary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        header i {
            font-size: 32px;
            color: var(--primary);
        }
        
        hr {
            border: 0;
            height: 1px;
            background: linear-gradient(to right, transparent, rgba(67, 97, 238, 0.3), transparent);
            margin: 25px 0;
        }
        
        h3 {
            font-size: 20px;
            margin-bottom: 20px;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        h3 i {
            width: 30px;
            height: 30px;
            background: rgba(67, 97, 238, 0.1);
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        
        .input-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary);
            font-size: 18px;
        }
        
        input[type="email"],
        input[type="password"],
        input[type="text"] {
            width: 100%;
            padding: 15px 15px 15px 50px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
            background-color: #f8f9fa;
        }
        
        input:focus {
            outline: none;
            border-color: var(--primary);
            background-color: white;
            box-shadow: 0 0 0 4px rgba(67, 97, 238, 0.1);
        }
        
        input:disabled {
            background-color: #e9ecef;
            color: #6c757d;
        }
        
        button {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.4);
        }
        
        button:active {
            transform: translateY(0);
        }
        
        .message {
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        .error {
            background-color: #fff5f7;
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        .success {
            background-color: #f0fdf4;
            color: #16a34a;
            border-left: 4px solid #16a34a;
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 25px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .back-link:hover {
            color: var(--secondary);
            transform: translateX(-5px);
        }
        
        .password-container {
            position: relative;
        }
        
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
            transition: all 0.3s;
        }
        
        .toggle-password:hover {
            color: var(--primary);
        }
        
        @media (max-width: 768px) {
            .profile-box {
                padding: 30px 20px;
            }
            
            header {
                font-size: 24px;
            }

            .nav-tabs {
                flex-direction: column;
                gap: 5px;
            }

            .nav-link {
                padding: 8px 10px;
                text-align: center;
            }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="user-greeting">
        <h4>Hello <?= htmlspecialchars($_SESSION['username'] ?? 'Guest') ?>, manage your profile:</h4>
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link" href="search.php"><i class="fas fa-cloud-sun me-1"></i> Weather</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="home.php" id="clothTab"><i class="fas fa-tshirt me-1"></i> Cloth Adviser</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="profile.php"><i class="fas fa-user me-1"></i> Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
            </li>
        </ul>
    </div>

    <div class="container">
        <div class="profile-box">
            <header><i class="fas fa-user-circle"></i> User Profile</header>
            <hr>
            
            <?php if ($error): ?>
                <div class="message error">
                    <i class="fas fa-exclamation-circle"></i> 
                    <div><?php echo $error; ?></div>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="message success">
                    <i class="fas fa-check-circle"></i> 
                    <div><?php echo $success; ?></div>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <h3><i class="fas fa-envelope"></i> Update Email</h3>
                
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" placeholder="Current Email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                </div>
                
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="new_email" placeholder="New Email" required>
                </div>
                
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="current_password" placeholder="Current Password" required>
                </div>
                
                <button type="submit" name="update_email">
                    <i class="fas fa-save me-2"></i>Update Email
                </button>
            </form>
            
            <hr>
            
            <form method="POST">
                <h3><i class="fas fa-key"></i> Update Password</h3>
                
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="current_password" placeholder="Current Password" required>
                </div>
                
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <div class="password-container">
                        <input type="password" class="password-field" name="new_password" placeholder="New Password" required minlength="6">
                        <i class="fas fa-eye toggle-password"></i>
                    </div>
                </div>
                
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="confirm_password" placeholder="Confirm New Password" required minlength="6">
                </div>
                
                <button type="submit" name="update_password">
                    <i class="fas fa-sync-alt me-2"></i>Update Password
                </button>
            </form>
            
            <a href="weather_display.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <script>
        // Enhanced toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(icon => {
            icon.addEventListener('click', function() {
                const passwordField = this.previousElementSibling;
                const isPassword = passwordField.type === 'password';
                
                passwordField.type = isPassword ? 'text' : 'password';
                this.classList.toggle('fa-eye-slash', isPassword);
                this.classList.toggle('fa-eye', !isPassword);
                
                // Add animation
                this.style.transform = 'translateY(-50%) scale(1.2)';
                setTimeout(() => {
                    this.style.transform = 'translateY(-50%) scale(1)';
                }, 200);
            });
        });

        // Add input focus effects
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.querySelector('i').style.color = '#4361ee';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.querySelector('i').style.color = '';
            });
        });

        // Prevent form resubmission on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>