<?php
session_start();

// If user is not logged in, redirect to login page
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Get user data from session
$username = htmlspecialchars($_SESSION['username'] ?? 'User');
$avatarInitial = strtoupper(substr($username, 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Fashion Advisor ChatBot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <style>
        :root {
            --primary-color: #075e54;
            --secondary-color: #128c7e;
            --accent-color: #25d366;
            --light-bg: #f8f9fa;
            --dark-text: #333;
            --light-text: #f8f9fa;
            --user-message: #dcf8c6;
            --bot-message: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body, html {
            height: 100%;
            font-family: 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            color: var(--dark-text);
            background-color: #e5ddd5;
            background-image: url('https://web.whatsapp.com/img/bg-chat-tile-light_a4be512e7195b6b733d9110b408f075d.png');
            background-repeat: repeat;
        }
        
        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            max-width: 900px;
            margin: 0 auto;
            background-color: var(--light-bg);
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }
        
        /* Header Styles */
        .chat-header {
            width: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--light-text);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
            position: relative;
        }
        
        .chat-header h3 {
            margin: 0;
            font-weight: 600;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .chat-header i {
            font-size: 1.2rem;
        }
        
        /* Chat Area Styles */
        #response {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background-color: #e5ddd5;
            background-image: url('https://web.whatsapp.com/img/bg-chat-tile-light_a4be512e7195b6b733d9110b408f075d.png');
		
            background-repeat: repeat;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .message-container {
            display: flex;
            flex-direction: column;
            gap: 5px;
            animation: fadeIn 0.3s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .message-time {
            font-size: 0.7rem;
            color: #666;
            margin: 0 5px;
            align-self: flex-end;
        }
        
        .user-message {
            background-color: var(--user-message);
            padding: 12px 15px;
            border-radius: 18px 18px 0 18px;
            max-width: 80%;
            margin-left: auto;
            position: relative;
            box-shadow: var(--shadow);
            word-wrap: break-word;
            line-height: 1.4;
        }
        
        .bot-message {
            background-color: var(--bot-message);
            padding: 12px 15px;
            border-radius: 18px 18px 18px 0;
            max-width: 80%;
            margin-right: auto;
            box-shadow: var(--shadow);
            word-wrap: break-word;
            line-height: 1.4;
        }
        
        .bot-message img {
            max-width: 100%;
            border-radius: 8px;
            margin-top: 8px;
        }
        
        /* Input Area Styles */
        .input-container {
            width: 100%;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            padding: 12px 20px;
            border-top: 1px solid #ddd;
            z-index: 10;
        }
        
        .input-container input {
            flex: 1;
            border: none;
            outline: none;
            font-size: 1rem;
            padding: 12px 20px;
            background: white;
            border-radius: 25px;
            margin-right: 12px;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        
        .input-container input:focus {
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.2), 0 0 0 2px var(--accent-color);
        }
        
        .input-container button {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 0;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 48px;
            height: 48px;
            box-shadow: var(--shadow);
        }
        
        .input-container button:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--accent-color));
            transform: scale(1.05);
        }
        
        .input-container button:active {
            transform: scale(0.98);
        }
        
        /* Typing Indicator */
        .typing-indicator {
            display: inline-flex;
            align-items: center;
            background-color: var(--bot-message);
            padding: 12px 15px;
            border-radius: 18px 18px 18px 0;
            max-width: 80px;
            margin-right: auto;
            box-shadow: var(--shadow);
        }
        
        .typing-dot {
            width: 8px;
            height: 8px;
            background-color: #666;
            border-radius: 50%;
            margin: 0 3px;
            animation: typingAnimation 1.4s infinite ease-in-out;
        }
        
        .typing-dot:nth-child(1) {
            animation-delay: 0s;
        }
        
        .typing-dot:nth-child(2) {
            animation-delay: 0.2s;
        }
        
        .typing-dot:nth-child(3) {
            animation-delay: 0.4s;
        }
        
        @keyframes typingAnimation {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-4px); }
        }
        
        /* User Panel */
        .user-panel {
            position: absolute;
            top: 80px;
            right: 20px;
            background: white;
            padding: 15px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            z-index: 100;
            width: 250px;
            transform: translateY(-20px);
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
        }
        
        .user-panel.active {
            transform: translateY(0);
            opacity: 1;
            pointer-events: all;
        }
        
        .user-panel .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .user-panel .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .user-panel .user-name {
            font-weight: 600;
        }
        
        .user-panel .logout-btn {
            display: block;
            width: 100%;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .user-panel .logout-btn:hover {
            background-color: var(--secondary-color);
        }
        
        /* Menu Button */
        .menu-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 100;
            box-shadow: var(--shadow);
            transition: all 0.3s;
        }
        
        .menu-btn:hover {
            background-color: var(--secondary-color);
            transform: scale(1.1);
        }
        
        /* Welcome Message Animation */
        .welcome-message {
            animation: welcomeAnimation 1s ease-out;
        }
        
        @keyframes welcomeAnimation {
            0% { transform: translateY(20px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .app-container {
                max-width: 100%;
                border-radius: 0;
            }
            
            .user-message, .bot-message {
                max-width: 90%;
            }
            
            .input-container {
                padding: 10px 15px;
            }
            
            .input-container input {
                padding: 10px 15px;
            }
        }
    </style>
</head>
<body>
    <button class="menu-btn" id="menuBtn">
        <i class="fas fa-user"></i>
    </button>

    <div class="user-panel" id="userPanel">
        <div class="user-info">
            <div class="user-avatar"><?php echo $avatarInitial; ?></div>
            <div>
                <div class="user-name"><?php echo $username; ?></div>
                <small>Fashion Advisor User</small>
            </div>
        </div>
        <a href="logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>

    <div class="app-container">
        <div class="chat-header">
            <h3><i class="fas fa-tshirt"></i> Fashion Advisor</h3>
        </div>

        <div id="response"></div>

        <div class="input-container">
            <input type="text" id="userInput" placeholder="Ask about fashion trends, styling tips..." onkeypress="handleKeyPress(event)" />
            <button id="sendBtn" onclick="sendMessage()">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>

    <script>
        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            // Add welcome message
            const responseDiv = document.getElementById('response');
            const welcomeMessage = `
                <div class="message-container welcome-message">
                    <div class="bot-message">
                        <strong>Hello, <?php echo $username; ?>! 👋</strong><br><br>
                        I'm your personal Fashion Advisor. I can help you with:<br>
                        • Outfit suggestions for any occasion<br>
                        • Current fashion trends<br>
                        • Color coordination advice<br>
                        • Seasonal wardrobe tips<br><br>
                        What would you like to know about today?
                    </div>
                    <div class="message-time">${formatTime(new Date())}</div>
                </div>
            `;
            responseDiv.innerHTML += welcomeMessage;
            responseDiv.scrollTop = responseDiv.scrollHeight;
            
            // Initialize user panel toggle
            const menuBtn = document.getElementById('menuBtn');
            const userPanel = document.getElementById('userPanel');
            
            menuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                userPanel.classList.toggle('active');
            });
            
            document.addEventListener('click', function() {
                userPanel.classList.remove('active');
            });
            
            userPanel.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        });
        
        function formatTime(date) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        
        function handleKeyPress(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        }

        async function sendMessage() {
            const inputElem = document.getElementById('userInput');
            const sendBtn = document.getElementById('sendBtn');
            const input = inputElem.value.trim();
            const responseDiv = document.getElementById('response');

            if (!input) return;

            // Disable input during processing
            inputElem.disabled = true;
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
            
            // Add user message with timestamp
            const userMessageTime = formatTime(new Date());
            responseDiv.innerHTML += `
                <div class="message-container">
                    <div class="user-message">${input}</div>
                    <div class="message-time">${userMessageTime}</div>
                </div>
            `;
            
            // Create typing indicator
            const typingIndicatorId = 'typing-' + Date.now();
            responseDiv.innerHTML += `
                <div class="message-container" id="${typingIndicatorId}">
                    <div class="typing-indicator">
                        <span class="typing-dot"></span>
                        <span class="typing-dot"></span>
                        <span class="typing-dot"></span>
                    </div>
                </div>
            `;
            
            inputElem.value = '';
            responseDiv.scrollTop = responseDiv.scrollHeight;

            try {
                const response = await fetch(
                    'https://openrouter.ai/api/v1/chat/completions',
                    {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer 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',
                            'HTTP-Referer': 'https://www.sitename.com',
                            'X-Title': 'SiteName',
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            model: 'deepseek/deepseek-r1:free',
                            messages: [{ 
                                role: 'system', 
                                content: `You are a friendly fashion advisor expert named StyleBot. Provide stylish, practical fashion advice to <?php echo $username; ?>. Be knowledgeable about current trends, colors, fabrics, and styles for all occasions. Offer specific recommendations when possible. Use emojis sparingly to make the conversation engaging. Format your responses with clear paragraphs and bullet points when listing items.`
                            }, { 
                                role: 'user', 
                                content: input 
                            }],
                        }),
                    }
                );

                const data = await response.json();
                const markdownText = data.choices?.[0]?.message?.content || "I'm sorry, I couldn't process your request. Please try again.";
                const parsed = marked.parse(markdownText);
                const botMessageTime = formatTime(new Date());

                // Replace the typing indicator with the actual response
                const typingElement = document.getElementById(typingIndicatorId);
                if (typingElement) {
                    typingElement.innerHTML = `
                        <div class="bot-message">${parsed}</div>
                        <div class="message-time">${botMessageTime}</div>
                    `;
                }
            } catch (error) {
                console.error('Error:', error);
                const typingElement = document.getElementById(typingIndicatorId);
                const errorTime = formatTime(new Date());
                if (typingElement) {
                    typingElement.innerHTML = `
                        <div class="bot-message">Sorry, I encountered an error. Please try again later.</div>
                        <div class="message-time">${errorTime}</div>
                    `;
                }
            } finally {
                // Re-enable input
                inputElem.disabled = false;
                sendBtn.disabled = false;
                sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
                inputElem.focus();
                responseDiv.scrollTop = responseDiv.scrollHeight;
            }
        }
    </script>
</body>
</html>