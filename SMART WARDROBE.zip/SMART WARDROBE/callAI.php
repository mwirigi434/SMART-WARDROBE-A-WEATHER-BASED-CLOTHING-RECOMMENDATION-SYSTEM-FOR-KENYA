<?php
header('Content-Type: application/json');

// Function to fetch weather data with proper URL encoding
function fetchWeatherData() {
    // Properly encode the path to handle spaces
    $basePath = dirname($_SERVER['PHP_SELF']);
    $encodedPath = str_replace(' ', '%20', $basePath);
    $url = 'http://' . $_SERVER['HTTP_HOST'] . $encodedPath . '/kenya_weather.php';
    
    // Use cURL for more reliable requests
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FAILONERROR => true,
        CURLOPT_TIMEOUT => 10
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception("Failed to fetch weather data: " . $error);
    }
    
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Invalid weather data response");
    }
    
    return $data;
}

// Function to generate AI prompt
function generateClothingPrompt($weatherData) {
    $prompt = <<<PROMPT
You are a fashion expert specializing in Kenyan weather-appropriate clothing. 
Provide specific clothing recommendations for males, females, and children based on these weather conditions:

PROMPT;

    foreach ($weatherData['data'] as $city => $info) {
        if (isset($info['error'])) continue;
        
        $prompt .= sprintf(
            "\n\n**%s**\n- Temperature: %.1f°C (Feels like %.1f°C)\n- Conditions: %s\n- Humidity: %d%%\n- Wind: %.1f m/s",
            $city,
            $info['temperature'],
            $info['feels_like'],
            $info['description'],
            $info['humidity'],
            $info['wind_speed']
        );
    }

    $prompt .= <<<PROMPT


For each city, provide:
1. Male clothing recommendations for both casual and formal occasions
2. Female clothing recommendations for both casual and formal occasions
3. Children clothing recommendations for both casual and formal occasions

Consider:
-genrate image for both uropean and africans
- Practicality for the weather conditions
- Layering suggestions where appropriate
- Protection from sun/rain when needed

Format your response with clear city headings and bullet points for each gender category.
PROMPT;

    return $prompt;
}

// Function to call AI API
function getAIRecommendations($prompt) {
    $apiKey = "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";
    $url = "https://openrouter.ai/api/v1/chat/completions";
    
    $headers = [
        "Authorization: Bearer $apiKey",
        "Content-Type: application/json",
        "HTTP-Referer: " . $_SERVER['HTTP_HOST'],
        "X-Title: Kenya Weather Fashion Advisor"
    ];
    
    $payload = [
        "model" => "deepseek/deepseek-r1-0528-qwen3-8b:free",
        "messages" => [
            ["role" => "system", "content" => "You are a helpful fashion advisor specialized in Kenyan clothing and weather conditions."],
            ["role" => "user", "content" => $prompt]
        ],
        "max_tokens" => 2000,
        "temperature" => 0.7
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_TIMEOUT => 30
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($error) {
        throw new Exception("AI API connection failed: $error");
    }
    
    if ($httpCode !== 200) {
        throw new Exception("AI API returned HTTP $httpCode: $response");
    }
    
    $data = json_decode($response, true);
    return $data['choices'][0]['message']['content'];
}

// Main execution
try {
    // Step 1: Get current weather data
    $weatherData = fetchWeatherData();
    
    if ($weatherData['status'] !== 'success') {
        throw new Exception("Weather API returned error status");
    }
    
    // Step 2: Generate AI prompt
    $prompt = generateClothingPrompt($weatherData);
    
    // Step 3: Get AI recommendations
    $recommendations = getAIRecommendations($prompt);
    
    // Prepare final output
    $output = [
        'status' => 'success',
        'last_updated' => date('Y-m-d H:i:s'),
        'weather_summary' => [
            'cities_processed' => $weatherData['cities_fetched'],
            'total_cities' => $weatherData['total_cities']
        ],
        'recommendations' => $recommendations,
        'raw_weather_data' => $weatherData['data']
    ];
    
    echo json_encode($output, JSON_PRETTY_PRINT);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
}
?>