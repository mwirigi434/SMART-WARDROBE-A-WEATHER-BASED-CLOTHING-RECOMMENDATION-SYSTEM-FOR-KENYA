<?php
// Start the session securely
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'use_strict_mode' => true,
        'cookie_httponly' => true,
        'cookie_secure' => true, // Enable this if using HTTPS
        'cookie_samesite' => 'Strict'
    ]);
}

// Regenerate session ID to prevent session fixation attacks
session_regenerate_id(true);

// Unset all session variables
$_SESSION = array();

// Clear session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// Completely destroy the session
session_destroy();

// Clear any remaining session data in memory
unset($_SESSION);

// Redirect to login page with no-cache headers
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Location: index.php");

// Ensure no further code is executed
exit;
?>