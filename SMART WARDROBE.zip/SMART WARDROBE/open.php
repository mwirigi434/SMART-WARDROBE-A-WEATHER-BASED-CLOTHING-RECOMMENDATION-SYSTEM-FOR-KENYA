<?php
// Stability AI API Integration
$apiKey = 'sk-cD8tF5shwJjPgMFDslapRBnnzilgImyV4y1RYFUoF311aPpx';
$engineId = 'stable-diffusion-xl-1024-v1-0'; // Or another engine ID
$apiUrl = "https://api.stability.ai/v1/generation/{$engineId}/text-to-image";

// Prepare the request data
$requestData = [
    'text_prompts' => [
        [
            'text' => 'A majestic lion standing on a rock at sunset',
            'weight' => 1
        ]
    ],
    'cfg_scale' => 7,
    'height' => 1024,
    'width' => 1024,
    'samples' => 1,
    'steps' => 30,
];

// Initialize cURL
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json',
    "Authorization: Bearer {$apiKey}"
]);

// Execute and handle response
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    die('cURL error: ' . curl_error($ch));
}

curl_close($ch);

// Process the response
if ($httpCode === 200) {
    $responseData = json_decode($response, true);
    
    // Save the generated image
    foreach ($responseData['artifacts'] as $imageData) {
        $fileName = 'generated_image_' . time() . '.png';
        file_put_contents($fileName, base64_decode($imageData['base64']));
        echo "Image saved as {$fileName}";
    }
} else {
    echo "API request failed. Status code: {$httpCode}\n";
    echo "Response: {$response}";
}
?>