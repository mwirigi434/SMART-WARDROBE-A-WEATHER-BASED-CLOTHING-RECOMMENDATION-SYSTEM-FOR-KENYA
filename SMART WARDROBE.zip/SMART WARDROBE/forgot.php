<?php
// Secure session start
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'use_strict_mode' => true,
        'cookie_httponly' => true,
        'cookie_secure' => isset($_SERVER['HTTPS']), // Enable if using HTTPS
        'cookie_samesite' => 'Strict'
    ]);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Forgot Password</title>
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Security headers -->
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' https://cdnjs.cloudflare.com">
</head>

<body>
  <div class="container">
    <div class="form-box box">

      <?php
      include "connection.php";

      if (isset($_POST['reset'])) {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Basic validation
        if (empty($email) || empty($new_password) || empty($confirm_password)) {
          $_SESSION['error'] = "All fields are required.";
        } elseif ($new_password !== $confirm_password) {
          $_SESSION['error'] = "Passwords do not match. Please try again.";
        } else {
          // Check if the email exists in the database
          $sql = "SELECT * FROM users WHERE email='$email'";
          $res = mysqli_query($conn, $sql);

          if (mysqli_num_rows($res) > 0) {
            // Email exists, update the password (should be hashed in production)
            $update_sql = "UPDATE users SET password='$new_password' WHERE email='$email'";
            $update_res = mysqli_query($conn, $update_sql);

            if ($update_res) {
              $_SESSION['success'] = "Password reset successfully. You can now login with your new password.";
              header("Refresh: 3; url=login.php"); // Redirect after 3 seconds
            } else {
              $_SESSION['error'] = "Error updating password. Please try again.";
            }
          } else {
            $_SESSION['error'] = "Email not found. Please enter a valid email address.";
          }
        }

        // Display messages from session
        if (isset($_SESSION['error'])) {
          echo "<div class='message error'>
                  <p>".htmlspecialchars($_SESSION['error'])."</p>
                </div><br>";
          unset($_SESSION['error']);
          echo "<a href='forgot.php'><button class='btn'>Try Again</button></a>";
        } elseif (isset($_SESSION['success'])) {
          echo "<div class='message success'>
                  <p>".htmlspecialchars($_SESSION['success'])."</p>
                </div><br>";
          unset($_SESSION['success']);
        }
      } else {
      ?>

        <header>Forgot Password</header>
        <hr>
        <form action="#" method="POST" autocomplete="off">

          <div class="form-box">
            <div class="input-container">
              <i class="fa fa-envelope icon"></i>
              <input class="input-field" type="email" placeholder="Enter your email" name="email" required>
            </div>

            <div class="input-container">
              <i class="fa fa-lock icon"></i>
              <input class="input-field password" type="password" placeholder="Enter new password" name="new_password" required minlength="8">
              <i class="fa fa-eye toggle icon"></i>
            </div>

            <div class="input-container">
              <i class="fa fa-lock icon"></i>
              <input class="input-field password" type="password" placeholder="Confirm new password" name="confirm_password" required minlength="8">
              <i class="fa fa-eye toggle icon"></i>
            </div>
          </div>

          <input type="submit" name="reset" id="submit" value="Reset Password" class="button">

          <div class="links">
            Remember your password? <a href="login.php">Login Now</a>
          </div>

        </form>
      </div>
      <?php
      }
      ?>
  </div>

  <script>
    // Toggle password visibility for all password fields
    document.querySelectorAll('.toggle').forEach(toggle => {
      toggle.addEventListener('click', (e) => {
        const input = e.currentTarget.previousElementSibling;
        if (input.type === 'password') {
          input.type = 'text';
          e.currentTarget.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
          input.type = 'password';
          e.currentTarget.classList.replace('fa-eye-slash', 'fa-eye');
        }
      });
    });
  </script>
</body>

</html>