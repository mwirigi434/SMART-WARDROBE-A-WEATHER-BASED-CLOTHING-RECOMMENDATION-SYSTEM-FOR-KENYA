<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Function to fetch weather data with multiple fallback methods
function fetchWeatherData() {
    // Try local file first
    $localFile = __DIR__ . '/kenya_weather.php';
    if (file_exists($localFile)) {
        return @file_get_contents($localFile);
    }
    
    // Try HTTP request
    $url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/kenya_weather.php';
    $options = [
        'http' => [
            'timeout' => 5,
            'ignore_errors' => true
        ]
    ];
    $context = stream_context_create($options);
    return @file_get_contents($url, false, $context);
}

// Try to get weather data
$weatherJson = fetchWeatherData();
$weatherData = null;

if ($weatherJson !== false) {
    $weatherData = json_decode($weatherJson, true);
}

// If no valid data, use sample data without showing warning
if (!$weatherData || $weatherData['status'] !== 'success') {
    $weatherData = [
        'status' => 'success',
        'last_updated' => date('Y-m-d H:i:s'),
        'data' => [
            'Nairobi' => [
                'temperature' => 24,
                'feels_like' => 26,
                'weather' => 'Partly Cloudy',
                'description' => 'Partly cloudy with occasional sunshine',
                'humidity' => 65,
                'wind_speed' => 12,
                'visibility' => 10000,
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]
    ];
}

// Function to get appropriate weather icon
function getWeatherIcon($weatherCondition) {
    $weatherCondition = strtolower($weatherCondition);
    
    $icons = [
        'sun' => 'fa-sun text-warning',
        'clear' => 'fa-sun text-warning',
        'cloud' => 'fa-cloud text-secondary',
        'rain' => 'fa-cloud-rain text-primary',
        'thunder' => 'fa-bolt text-danger',
        'storm' => 'fa-bolt text-danger',
        'snow' => 'fa-snowflake text-info'
    ];
    
    foreach ($icons as $key => $icon) {
        if (strpos($weatherCondition, $key) !== false) {
            return '<i class="fas ' . $icon . '"></i>';
        }
    }
    
    return '<i class="fas fa-smog text-muted"></i>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kenya Weather Forecast</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #1e5799;
            --secondary-blue: #207cca;
            --light-bg: #f8f9fa;
            --card-bg: #ffffff;
            --text-dark: #2c3e50;
            --text-light: #6c757d;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-dark);
            padding-top: 20px;
            background-image: url('images/weather-bg.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(248, 249, 250, 0.9);
        }
        
        .user-greeting {
            background-color: rgba(32, 124, 202, 0.9);
            color: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .nav-tabs {
            margin-bottom: 0;
            border-bottom: none;
        }
        
        .nav-link {
            color: white;
            border: none;
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.3);
            font-weight: 600;
        }
        
        .weather-card {
            background-color: rgba(255,255,255,0.9);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            padding: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
            border-left: 4px solid var(--secondary-blue);
            height: 100%;
            backdrop-filter: blur(3px);
        }
        
        /* Modal styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            transform: translateY(-20px);
            transition: transform 0.3s ease;
        }
        
        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }
        
        .modal-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .modal-btn {
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .modal-btn-yes {
            background-color: var(--secondary-blue);
            color: white;
            border: none;
        }
        
        .modal-btn-yes:hover {
            background-color: #1a68b5;
            transform: translateY(-2px);
        }
        
        .modal-btn-no {
            background-color: white;
            color: var(--secondary-blue);
            border: 1px solid var(--secondary-blue);
        }
        
        /* Loading screen */
        .loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(255,255,255,0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }
        
        .loading-screen.active {
            opacity: 1;
            visibility: visible;
        }
        
        .loading-spinner {
            width: 80px;
            height: 80px;
            border: 8px solid #f3f3f3;
            border-top: 8px solid var(--secondary-blue);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loading-text {
            font-size: 1.2rem;
            color: var(--secondary-blue);
            margin-top: 20px;
            text-align: center;
        }
        
        .loading-icons {
            display: flex;
            gap: 20px;
            margin-top: 30px;
        }
        
        .loading-icon {
            font-size: 2rem;
            color: var(--secondary-blue);
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
        }
        
        .loading-icon:nth-child(1) { animation-delay: 0.1s; }
        .loading-icon:nth-child(2) { animation-delay: 0.3s; }
        .loading-icon:nth-child(3) { animation-delay: 0.5s; }
    </style>
</head>
<body>
    <div class="container">
        <!-- User Greeting Section with Tabs -->
        <div class="user-greeting">
            <h4>Hello <?= htmlspecialchars($_SESSION['username']) ?>, today's weather data:</h4>
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="search.php"><i class="fas fa-cloud-sun me-1"></i> Weather</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" id="clothTab"><i class="fas fa-tshirt me-1"></i> Cloth</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php"><i class="fas fa-user me-1"></i> Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
                </li>
            </ul>
        </div>
        
        <div class="update-info bg-white p-2 rounded shadow-sm mb-3">
            <i class="fas fa-sync-alt"></i> Last updated: <?= htmlspecialchars($weatherData['last_updated']) ?>
        </div>
        
        <div class="row">
            <?php foreach ($weatherData['data'] as $city => $data): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="weather-card <?= isset($data['error']) ? 'error-card' : '' ?>">
                        <div class="card-city">
                            <i class="fas fa-city"></i>
                            <?= htmlspecialchars($city) ?>
                        </div>
                        
                        <?php if (!isset($data['error'])): ?>
                            <div class="card-temp"><?= round($data['temperature']) ?>°C</div>
                            <div class="card-feels-like">
                                Feels like <?= round($data['feels_like']) ?>°C
                            </div>
                            
                            <div class="current-condition mb-3">
                                <?= getWeatherIcon($data['weather']) ?>
                                <?= htmlspecialchars($data['weather']) ?> - <?= htmlspecialchars($data['description']) ?>
                            </div>
                            
                            <div class="weather-details">
                                <div class="detail-item">
                                    <span class="detail-icon"><i class="fas fa-tint"></i></span>
                                    <span class="detail-label">Humidity:</span>
                                    <span><?= $data['humidity'] ?>%</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-icon"><i class="fas fa-wind"></i></span>
                                    <span class="detail-label">Wind:</span>
                                    <span><?= $data['wind_speed'] ?> m/s</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-icon"><i class="fas fa-eye"></i></span>
                                    <span class="detail-label">Visibility:</span>
                                    <span><?= isset($data['visibility']) ? ($data['visibility'] / 1000) . ' km' : 'N/A' ?></span>
                                </div>
                            </div>
                            
                            <div class="last-updated">
                                <i class="fas fa-clock"></i> Updated: <?= date('H:i', strtotime($data['timestamp'])) ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger mt-3">
                                <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($data['error']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Cloth Recommendation Modal -->
    <div class="modal-overlay" id="clothModal">
        <div class="modal-content">
            <h3 class="mb-4"><i class="fas fa-tshirt text-primary me-2"></i> Clothing Recommendation</h3>
            <p class="mb-4">Would you like personalized clothing recommendations based on the current weather conditions?</p>
            <div class="modal-buttons">
                <button class="modal-btn modal-btn-yes" id="confirmYes">
                    <i class="fas fa-check-circle me-2"></i>Yes, please!
                </button>
                <button class="modal-btn modal-btn-no" id="confirmNo">
                    <i class="fas fa-times-circle me-2"></i>Not now
                </button>
            </div>
        </div>
    </div>

    <!-- Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loading-spinner"></div>
        <div class="loading-text">Preparing your perfect outfit recommendations...</div>
        <div class="loading-icons">
            <div class="loading-icon"><i class="fas fa-tshirt"></i></div>
            <div class="loading-icon"><i class="fas fa-socks"></i></div>
            <div class="loading-icon"><i class="fas fa-umbrella"></i></div>
        </div>
    </div>

    <footer class="footer mt-5 py-4 bg-light bg-opacity-75 rounded">
        <div class="container text-center">
            <p class="mb-0">Kenya Weather Forecast &copy; <?= date('Y') ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Cloth recommendation modal functionality
        const clothTab = document.getElementById('clothTab');
        const clothModal = document.getElementById('clothModal');
        const confirmYes = document.getElementById('confirmYes');
        const confirmNo = document.getElementById('confirmNo');
        const loadingScreen = document.getElementById('loadingScreen');
        
        clothTab.addEventListener('click', function(e) {
            e.preventDefault();
            clothModal.classList.add('active');
        });
        
        confirmYes.addEventListener('click', function() {
            // Show loading screen
            clothModal.classList.remove('active');
            loadingScreen.classList.add('active');
            
            // Redirect after a delay to show the loading animation
            setTimeout(() => {
                window.location.href = 'cloth.php';
            }, 2500); // 2.5 seconds delay
        });
        
        confirmNo.addEventListener('click', function() {
            clothModal.classList.remove('active');
        });
        
        // Close modal when clicking outside
        clothModal.addEventListener('click', function(e) {
            if (e.target === clothModal) {
                clothModal.classList.remove('active');
            }
        });

        // Auto-refresh every 5 minutes
        setTimeout(() => {
            window.location.reload();
        }, 300000);
    </script>
</body>
</html>