<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include "connection.php";

// Fetch all users
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background:#f8f9fa; font-family:Arial,sans-serif; margin:0; display:flex; align-items:flex-start; }
    .sidebar { width:220px; background:#207cca; color:white; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; padding-top:20px; }
    .sidebar .logo { text-align:center; font-size:18px; font-weight:bold; margin-bottom:20px; }
    .sidebar a { color:white; text-decoration:none; padding:12px 20px; display:block; transition:0.3s; }
    .sidebar a:hover { background:#174b82; }
    .sidebar .logout-btn { margin-top:auto; background:#dc3545; text-align:center; padding:12px; border-radius:0; }
    .sidebar .logout-btn:hover { background:#c82333; }
    .container { margin-left:220px; padding:20px; width:calc(100% - 220px); }
    table { width:100%; border-collapse:collapse; background:white; border-radius:6px; overflow:hidden; }
    th, td { padding:12px; border:1px solid #ddd; text-align:center; }
    th { background:#207cca; color:white; position:sticky; top:0; }
    .action-btn { margin:0 3px; padding:5px 10px; border-radius:4px; text-decoration:none; color:white; font-size:14px; }
    .edit-btn { background:#28a745; } .edit-btn:hover { background:#218838; }
    .delete-btn { background:#dc3545; } .delete-btn:hover { background:#c82333; }
    .message.success { background:#d4edda; color:#155724; padding:10px; border-radius:5px; margin-bottom:15px; }
  </style>
</head>
<body>
  <!-- SIDEBAR -->
  <div class="sidebar">
      <div class="logo"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['username']) ?></div>
      <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="add_user.php"><i class="fas fa-user-plus"></i> Add User</a>
      <a href="weather_display.php"><i class="fas fa-cloud-sun"></i> weather analysis</a>
      <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
      <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
      <a href="generate_report.php"><i class="fas fa-file-alt"></i> Report</a>
      <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <!-- MAIN CONTENT -->
  <div class="container">
      <?php if (isset($_SESSION['success'])): ?>
          <div class="message success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
      <?php endif; ?>

      <!-- Users Table -->
      <table>
          <thead>
          <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Actions</th>
          </tr>
          </thead>
          <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                  <td><?= $row['id'] ?></td>
                  <td><?= htmlspecialchars($row['username']) ?></td>
                  <td><?= htmlspecialchars($row['email']) ?></td>
                  <td>
                      <a href="edit_user.php?id=<?= $row['id'] ?>" class="action-btn edit-btn"><i class="fas fa-edit"></i> Edit</a>
                      <a href="delete_user.php?id=<?= $row['id'] ?>" class="action-btn delete-btn" onclick="return confirm('Delete this user?');"><i class="fas fa-trash"></i> Delete</a>
                  </td>
              </tr>
          <?php endwhile; ?>
          </tbody>
      </table>
  </div>
</body>
</html>
