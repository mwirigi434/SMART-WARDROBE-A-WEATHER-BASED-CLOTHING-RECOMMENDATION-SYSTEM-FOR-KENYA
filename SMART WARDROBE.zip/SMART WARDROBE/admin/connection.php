<?php

$server = "localhost";
$username = "root";
$password = "Liam5641.";
$db = "wardrobe_db";

$conn = new mysqli($server, $username, $password, $db);

?>