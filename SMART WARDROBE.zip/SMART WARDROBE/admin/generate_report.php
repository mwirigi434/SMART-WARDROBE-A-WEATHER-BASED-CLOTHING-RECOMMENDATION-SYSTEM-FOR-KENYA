<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include "connection.php";

// Check admin privileges
$user_id = $_SESSION['id'];
$check_admin = mysqli_query($conn, "SELECT * FROM admin WHERE id = $user_id");
if (mysqli_num_rows($check_admin) === 0) {
    header("Location: weather_display.php");
    exit();
}

// Image settings
$width = 800;
$height = 600;
$image = imagecreatetruecolor($width, $height);
$bg = imagecolorallocate($image, 255, 255, 255);
$text_color = imagecolorallocate($image, 0, 0, 0);
$header_color = imagecolorallocate($image, 0, 102, 204);
imagefilledrectangle($image, 0, 0, $width, $height, $bg);

// Title
imagestring($image, 5, 250, 20, 'Users Report - ' . date('Y-m-d'), $header_color);

// Table headers
$y = 60;
imagestring($image, 4, 20, $y, 'ID', $text_color);
imagestring($image, 4, 70, $y, 'Username', $text_color);
imagestring($image, 4, 220, $y, 'Email', $text_color);
imagestring($image, 4, 450, $y, 'Role', $text_color);
imagestring($image, 4, 550, $y, 'Join Date', $text_color);

// Get admin IDs
$admin_ids = [];
$admins = mysqli_query($conn, "SELECT id FROM admin");
while ($admin = mysqli_fetch_assoc($admins)) {
    $admin_ids[] = $admin['id'];
}

// User rows
$y += 20;
$users = mysqli_query($conn, "SELECT id, username, email, created_at FROM users ORDER BY created_at DESC");
while ($user = mysqli_fetch_assoc($users)) {
    $role = in_array($user['id'], $admin_ids) ? 'Admin' : 'User';
    imagestring($image, 3, 20, $y, $user['id'], $text_color);
    imagestring($image, 3, 70, $y, $user['username'], $text_color);
    imagestring($image, 3, 220, $y, $user['email'], $text_color);
    imagestring($image, 3, 450, $y, $role, $text_color);
    imagestring($image, 3, 550, $y, date('Y-m-d', strtotime($user['created_at'])), $text_color);
    $y += 20;
    if ($y > $height - 40) break; // Prevent overflow
}

// Summary
imagestring($image, 4, 20, $height - 30, 'Total Users: ' . mysqli_num_rows($users), $header_color);

// Output image
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
exit();