<?php
header('Content-Type: application/json');

class WeatherFetcher {
    private $apiKey = '5e3864f214157b0f95954457ebfb9766';
    
    public function getWeatherData($city, $country = 'KE') {
        $url = "https://api.openweathermap.org/data/2.5/weather?q=" . 
               urlencode($city) . "," . urlencode($country) . 
               "&units=metric&appid=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FAILONERROR => true
        ]);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($error) {
            throw new Exception("CURL Error: $error");
        }
        
        if ($httpCode !== 200) {
            throw new Exception("API returned HTTP $httpCode");
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response");
        }
        
        return $data;
    }
}

$kenyanCities = [
    'Nairobi', 'Mombasa', 'Kisumu', 'Nakuru', 'Eldoret',
    'Thika', 'Malindi', 'Kitale', 'Kakamega', 'Kisii', 'Meru'
];

$weatherFetcher = new WeatherFetcher();
$weatherData = [];
$successCount = 0;

foreach ($kenyanCities as $city) {
    try {
        $data = $weatherFetcher->getWeatherData($city);
        
        $weatherData[$city] = [
            'temperature' => round($data['main']['temp'], 1),
            'feels_like' => round($data['main']['feels_like'], 1),
            'humidity' => $data['main']['humidity'],
            'weather' => $data['weather'][0]['main'],
            'description' => ucfirst($data['weather'][0]['description']),
            'wind_speed' => round($data['wind']['speed'], 1),
            'icon' => $data['weather'][0]['icon'],
            'timestamp' => date('Y-m-d H:i:s', $data['dt'])
        ];
        $successCount++;
        
    } catch (Exception $e) {
        $weatherData[$city] = [
            'error' => 'Failed to fetch data',
            'details' => $e->getMessage()
        ];
    }
}

echo json_encode([
    'status' => $successCount > 0 ? 'success' : 'error',
    'country' => 'Kenya',
    'cities_fetched' => $successCount,
    'total_cities' => count($kenyanCities),
    'last_updated' => date('Y-m-d H:i:s'),
    'data' => $weatherData
], JSON_PRETTY_PRINT);
?>