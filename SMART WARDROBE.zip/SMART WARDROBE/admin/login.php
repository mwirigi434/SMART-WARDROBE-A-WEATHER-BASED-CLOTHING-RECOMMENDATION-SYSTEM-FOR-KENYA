<?php
session_start();
include "connection.php";

if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    $sql = "SELECT * FROM admin WHERE LOWER(email) = LOWER(?) LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($res)) {
        $password = trim($row['password']); // stored in DB

        if ($pass === $password) { // plain text match
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            echo "<div class='message'><p>Wrong Password</p></div><br>";
        }
    } else {
        echo "<div class='message'><p>Wrong Email or Password</p></div><br>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ADMIN LOGIN</title>
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <div class="container">
    <div class="form-box box">
      <header>ADMIN LOGIN</header>
      <hr>
      <form action="#" method="POST">
        <div class="form-box">
          <div class="input-container">
            <i class="fa fa-envelope icon"></i>
            <input class="input-field" type="email" placeholder="Email Address" name="email" required>
          </div>
          <div class="input-container">
            <i class="fa fa-lock icon"></i>
            <input class="input-field password" type="password" placeholder="Password" name="password" required>
            <i class="fa fa-eye toggle icon"></i>
          </div>
          <div class="remember">
            <input type="checkbox" class="check" name="remember_me">
            <label for="remember">Remember me</label>
            <span><a href="forgot_password.php">Forgot password</a></span>
          </div>
        </div>
        <input type="submit" name="login" id="submit" value="Login" class="button">
      </form>
    </div>
  </div>

  <script>
    const toggle = document.querySelector(".toggle"),
          input = document.querySelector(".password");
    toggle.addEventListener("click", () => {
      if (input.type === "password") {
        input.type = "text";
        toggle.classList.replace("fa-eye", "fa-eye-slash");
      } else {
        input.type = "password";
        toggle.classList.replace("fa-eye-slash", "fa-eye");
      }
    });
  </script>
</body>
</html>
