<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include "connection.php";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);
    $hashed   = password_hash($password, PASSWORD_DEFAULT);

    if (!empty($username) && !empty($email) && !empty($password)) {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed);

        if ($stmt->execute()) {
            $_SESSION['success'] = "User added successfully!";
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error = "Failed to add user.";
        }
    } else {
        $error = "All fields are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add User</title>
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background:#f8f9fa; font-family:Arial,sans-serif; margin:0; display:flex; align-items:flex-start; }
    .sidebar { width:220px; background:#207cca; color:white; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; padding-top:20px; }
    .sidebar .logo { text-align:center; font-size:18px; font-weight:bold; margin-bottom:20px; }
    .sidebar a { color:white; text-decoration:none; padding:12px 20px; display:block; transition:0.3s; }
    .sidebar a:hover { background:#174b82; }
    .sidebar .logout-btn { margin-top:auto; background:#dc3545; text-align:center; padding:12px; border-radius:0; }
    .sidebar .logout-btn:hover { background:#c82333; }
    .container { margin-left:220px; padding:20px; width:calc(100% - 220px); }
    .form-box { background:white; padding:25px; border-radius:6px; box-shadow:0 2px 6px rgba(0,0,0,0.1); max-width:500px; margin:auto; }
    .form-box h2 { margin-bottom:20px; color:#207cca; }
    .form-box input { width:100%; padding:10px; margin:10px 0; border:1px solid #ccc; border-radius:4px; }
    .form-box button { background:#207cca; color:white; border:none; padding:10px 15px; border-radius:4px; cursor:pointer; }
    .form-box button:hover { background:#174b82; }
    .message.error { background:#f8d7da; color:#721c24; padding:10px; border-radius:5px; margin-bottom:15px; }
  </style>
</head>
<body>
  <!-- SIDEBAR -->
  <div class="sidebar">
      <div class="logo"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['username']) ?></div>
      <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="add_user.php" class="active"><i class="fas fa-user-plus"></i> Add User</a>
      <a href="weather_display.php"><i class="fas fa-cloud-sun"></i> weather analysis</a>
      <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
      <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
      <a href="generate_report.php"><i class="fas fa-file-alt"></i> Report</a>
      <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <!-- MAIN CONTENT -->
  <div class="container">
      <div class="form-box">
          <h2><i class="fas fa-user-plus"></i> Add New User</h2>
          
          <?php if (!empty($error)): ?>
              <div class="message error"><?= $error ?></div>
          <?php endif; ?>

          <form method="POST" action="">
              <input type="text" name="username" placeholder="Enter username" required>
              <input type="email" name="email" placeholder="Enter email" required>
              <input type="password" name="password" placeholder="Enter password" required>
              <button type="submit"><i class="fas fa-plus-circle"></i> Add User</button>
          </form>
      </div>
  </div>
</body>
</html>
