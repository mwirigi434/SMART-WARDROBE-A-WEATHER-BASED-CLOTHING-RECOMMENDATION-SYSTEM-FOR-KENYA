<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
include "connection.php";

$message = "";
if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);
    $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $message = "User deleted successfully.";
    } else {
        $message = "Error deleting user.";
    }
} else {
    $message = "Invalid request.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete User</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background:#f8f9fa; font-family:Arial,sans-serif; margin:0; display:flex; align-items:flex-start; }
    .sidebar { width:220px; background:#207cca; color:white; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; padding-top:20px; }
    .sidebar .logo { text-align:center; font-size:18px; font-weight:bold; margin-bottom:20px; }
    .sidebar a { color:white; text-decoration:none; padding:12px 20px; display:block; transition:0.3s; }
    .sidebar a:hover { background:#174b82; }
    .sidebar .logout-btn { margin-top:auto; background:#dc3545; text-align:center; padding:12px; border-radius:0; }
    .sidebar .logout-btn:hover { background:#c82333; }
    .container { margin-left:220px; padding:20px; width:calc(100% - 220px); }
    .box { background:white; padding:25px; border-radius:6px; box-shadow:0 2px 6px rgba(0,0,0,0.1); max-width:500px; text-align:center; }
    h2 { margin-top:0; color:#207cca; }
    .success { background:#d4edda; color:#155724; padding:10px; border-radius:5px; margin-bottom:15px; }
    .error { background:#f8d7da; color:#721c24; padding:10px; border-radius:5px; margin-bottom:15px; }
    .btn { display:inline-block; padding:10px 15px; border-radius:4px; text-decoration:none; margin-top:10px; }
    .btn-back { background:#6c757d; color:white; }
    .btn-back:hover { background:#5a6268; }
  </style>
</head>
<body>
  <!-- SIDEBAR -->
  <div class="sidebar">
      <div class="logo"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['username']) ?></div>
      <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="add_user.php"><i class="fas fa-user-plus"></i> Add User</a>
      <a href="weather_display.php"><i class="fas fa-cloud-sun"></i> Weather</a>
      <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
      <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
      <a href="generate_report.php"><i class="fas fa-file-alt"></i> Report</a>
      <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <!-- MAIN CONTENT -->
  <div class="container">
    <div class="box">
      <h2><i class="fas fa-trash"></i> Delete User</h2>
      <?php if (strpos($message, "successfully")): ?>
          <div class="success"><i class="fas fa-check-circle"></i> <?= $message ?></div>
      <?php else: ?>
          <div class="error"><i class="fas fa-exclamation-circle"></i> <?= $message ?></div>
      <?php endif; ?>
      <a href="admin_dashboard.php" class="btn btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
