<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

class WeatherFetcher {
    private $apiKey = "5e3864f214157b0f95954457ebfb9766";

    public function getWeatherData($city, $country = 'KE') {
        $url = "https://api.openweathermap.org/data/2.5/weather?q=" . 
               urlencode($city) . "," . urlencode($country) . 
               "&units=metric&appid=" . $this->apiKey;

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FAILONERROR => true
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($error) throw new Exception("CURL Error: $error");
        if ($httpCode !== 200) throw new Exception("API returned HTTP $httpCode");

        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) throw new Exception("Invalid JSON response");

        return $data;
    }
}

$weatherData = null;
$errorMsg = null;
$fetcher = new WeatherFetcher();

// Default city
$city = "Nairobi";

// If user searches for another city, override default
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['city'])) {
    $city = trim($_POST['city']);
}

try {
    $data = $fetcher->getWeatherData($city);

    $weatherData = [
        "city" => $city,
        "temperature" => round($data['main']['temp'], 1),
        "feels_like" => round($data['main']['feels_like'], 1),
        "humidity" => $data['main']['humidity'],
        "weather" => $data['weather'][0]['main'],
        "description" => ucfirst($data['weather'][0]['description']),
        "wind_speed" => round($data['wind']['speed'], 1),
        "timestamp" => date("Y-m-d H:i:s", $data['dt'])
    ];
} catch (Exception $e) {
    $errorMsg = "Could not fetch data for $city. (" . $e->getMessage() . ")";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Weather Analysis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background:#f8f9fa; font-family:Arial,sans-serif; margin:0; display:flex; align-items:flex-start; }
        .sidebar { width:220px; background:#207cca; color:white; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; padding-top:20px; }
        .sidebar .logo { text-align:center; font-size:18px; font-weight:bold; margin-bottom:20px; }
        .sidebar a { color:white; text-decoration:none; padding:12px 20px; display:block; transition:0.3s; }
        .sidebar a:hover { background:#174b82; }
        .sidebar .logout-btn { margin-top:auto; background:#dc3545; text-align:center; padding:12px; border-radius:0; }
        .sidebar .logout-btn:hover { background:#c82333; }
        .container { margin-left:220px; padding:20px; width:calc(100% - 220px); }
    </style>
</head>
<body>
  <!-- SIDEBAR -->
  <div class="sidebar">
      <div class="logo"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['username']) ?></div>
      <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="add_user.php"><i class="fas fa-user-plus"></i> Add User</a>
      <a href="weather_display.php"><i class="fas fa-cloud-sun"></i>weather analysis</a>
      <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
      <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
      <a href="generate_report.php"><i class="fas fa-file-alt"></i> Report</a>
      <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <!-- MAIN CONTENT -->
  <div class="container py-4">
      <h1 class="mb-4">Weather Analysis Tool</h1>
      <p>Welcome, <b><?php echo htmlspecialchars($_SESSION['username']); ?></b></p>

      <!-- City Input Form -->
      <form method="POST" class="mb-4">
          <div class="input-group">
              <input type="text" name="city" class="form-control" placeholder="Enter City Name..." required>
              <button class="btn btn-primary">Get Weather</button>
          </div>
      </form>

      <?php if ($errorMsg): ?>
          <div class="alert alert-danger"><?php echo $errorMsg; ?></div>
      <?php endif; ?>

      <?php if ($weatherData): ?>
          <div class="card p-3 shadow-sm">
              <h3><?php echo htmlspecialchars($weatherData['city']); ?> Weather</h3>
              <p><b>Temperature:</b> <?php echo $weatherData['temperature']; ?>°C</p>
              <p><b>Feels Like:</b> <?php echo $weatherData['feels_like']; ?>°C</p>
              <p><b>Condition:</b> <?php echo $weatherData['weather']; ?> (<?php echo $weatherData['description']; ?>)</p>
              <p><b>Humidity:</b> <?php echo $weatherData['humidity']; ?>%</p>
              <p><b>Wind Speed:</b> <?php echo $weatherData['wind_speed']; ?> m/s</p>
              <p><b>Updated:</b> <?php echo $weatherData['timestamp']; ?></p>

              <!-- Graphs -->
              <div class="row">
                  <div class="col-md-6">
                      <canvas id="tempChart"></canvas>
                  </div>
                  <div class="col-md-6">
                      <canvas id="otherChart"></canvas>
                  </div>
              </div>

              <button onclick="window.print()" class="btn btn-success mt-3">Print Analysis</button>
          </div>

          <script>
          // Line Chart for Temperature vs Feels Like
          const tempCtx = document.getElementById('tempChart').getContext('2d');
          new Chart(tempCtx, {
              type: 'line',
              data: {
                  labels: ['Temperature', 'Feels Like'],
                  datasets: [{
                      label: 'Temperature (°C)',
                      data: [<?php echo $weatherData['temperature']; ?>, <?php echo $weatherData['feels_like']; ?>],
                      borderColor: '#007bff',
                      backgroundColor: 'rgba(0, 123, 255, 0.2)',
                      fill: true,
                      tension: 0.3,
                      pointBackgroundColor: '#007bff',
                      pointBorderColor: '#fff',
                      pointRadius: 6,
                      pointHoverRadius: 8
                  }]
              },
              options: {
                  responsive: true,
                  plugins: { legend: { display: true, position: 'top' } }
              }
          });

          // Pie Chart for Humidity vs Wind Speed
          const otherCtx = document.getElementById('otherChart').getContext('2d');
          new Chart(otherCtx, {
              type: 'pie',
              data: {
                  labels: ['Humidity %', 'Wind Speed m/s'],
                  datasets: [{
                      label: 'Weather Stats',
                      data: [<?php echo $weatherData['humidity']; ?>, <?php echo $weatherData['wind_speed']; ?>],
                      backgroundColor: ['#28a745','#ffc107'],
                      borderColor: ['#ffffff','#ffffff'],
                      borderWidth: 2
                  }]
              },
              options: {
                  responsive: true,
                  plugins: { legend: { display: true, position: 'bottom' } }
              }
          });
          </script>
      <?php endif; ?>
  </div>
</body>
</html>
