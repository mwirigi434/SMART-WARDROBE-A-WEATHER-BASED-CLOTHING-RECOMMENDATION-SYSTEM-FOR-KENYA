<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include "connection.php";

// Function to normalize Kenyan phone numbers
function normalizePhone($phone) {
    // Remove spaces, dashes, and any non-numeric characters
    $phone = preg_replace('/\D/', '', trim($phone));

    // Case 1: 07XXXXXXXX (10 digits starting with 0)
    if (strlen($phone) === 10 && $phone[0] === '0') {
        return '+254' . substr($phone, 1);
    }

    // Case 2: 7XXXXXXXX (9 digits starting with 7)
    if (strlen($phone) === 9 && $phone[0] === '7') {
        return '+254' . $phone;
    }

    // Case 3: 2547XXXXXXXX (12 digits starting with 254)
    if (strlen($phone) === 12 && substr($phone, 0, 3) === '254') {
        return '+' . $phone;
    }

    // Case 4: Already normalized (+2547XXXXXXXX)
    if (strlen($phone) === 13 && substr($phone, 0, 4) === '254') {
        return '+' . $phone;
    }
    if (strlen($phone) === 13 && substr($phone, 0, 4) === '+254') {
        return $phone;
    }

    // Default: return as-is (invalid format)
    return $phone;
}

// Fetch admin details
$admin_id = $_SESSION['id'];
$sql = "SELECT * FROM admin WHERE id='$admin_id' LIMIT 1";
$result = mysqli_query($conn, $sql);
$admin = mysqli_fetch_assoc($result);

// Update profile
if (isset($_POST['update'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $phone    = mysqli_real_escape_string($conn, $_POST['phone']);
    $phone    = normalizePhone($phone); // ✅ Normalize before saving
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // If password is empty, keep the old one
    if (empty($password)) {
        $password = $admin['password'];
    }

    $update = "UPDATE admin 
               SET username='$username', email='$email', phone='$phone', password='$password' 
               WHERE id='$admin_id'";
    if (mysqli_query($conn, $update)) {
        $_SESSION['username'] = $username;
        $success = "Profile updated successfully!";
        // Refresh data
        $sql = "SELECT * FROM admin WHERE id='$admin_id' LIMIT 1";
        $result = mysqli_query($conn, $sql);
        $admin = mysqli_fetch_assoc($result);
    } else {
        $error = "Error updating profile!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin Profile</title>
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="admin_dashboard.php">Admin Panel</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link active" href="profile.php">Profile</a></li>
          <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Profile Form -->
  <div class="container mt-4">
    <div class="card shadow p-4">
      <h3 class="mb-3">Update Profile</h3>

      <?php if (isset($success)) { ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php } ?>
      <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php } ?>

      <form method="POST" action="">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($admin['username']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($admin['email']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($admin['phone']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password (leave blank to keep current)</label>
          <input type="password" name="password" class="form-control">
        </div>
        <button type="submit" name="update" class="btn btn-primary">Update Profile</button>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
