<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
include "connection.php";

if (!isset($_GET['id'])) {
    header("Location: admin_dashboard.php");
    exit();
}
$user_id = intval($_GET['id']);

// Get user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if (!$user) {
    $_SESSION['success'] = "User not found.";
    header("Location: admin_dashboard.php");
    exit();
}

// Handle update
if (isset($_POST['update'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($email)) {
        $error = "Username and Email are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET username=?, email=?, password=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $username, $email, $hashed, $user_id);
        } else {
            $sql = "UPDATE users SET username=?, email=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $username, $email, $user_id);
        }

        if ($stmt->execute()) {
            $_SESSION['success'] = "User updated successfully.";
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error = "Update failed.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit User</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background:#f8f9fa; font-family:Arial,sans-serif; margin:0; display:flex; align-items:flex-start; }
    .sidebar { width:220px; background:#207cca; color:white; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; padding-top:20px; }
    .sidebar .logo { text-align:center; font-size:18px; font-weight:bold; margin-bottom:20px; }
    .sidebar a { color:white; text-decoration:none; padding:12px 20px; display:block; transition:0.3s; }
    .sidebar a:hover { background:#174b82; }
    .sidebar .logout-btn { margin-top:auto; background:#dc3545; text-align:center; padding:12px; border-radius:0; }
    .sidebar .logout-btn:hover { background:#c82333; }
    .container { margin-left:220px; padding:20px; width:calc(100% - 220px); }
    .form-box { background:white; padding:25px; border-radius:6px; box-shadow:0 2px 6px rgba(0,0,0,0.1); max-width:500px; }
    h2 { margin-top:0; color:#207cca; }
    label { display:block; margin:12px 0 6px; font-weight:bold; }
    input[type="text"], input[type="email"], input[type="password"] { width:100%; padding:10px; border:1px solid #ccc; border-radius:4px; }
    button { background:#28a745; color:white; border:none; padding:10px 15px; border-radius:4px; cursor:pointer; margin-top:15px; }
    button:hover { background:#218838; }
    .cancel-btn { display:inline-block; margin-left:10px; padding:10px 15px; background:#6c757d; color:white; border-radius:4px; text-decoration:none; }
    .cancel-btn:hover { background:#5a6268; }
    .error { color:#dc3545; margin-bottom:10px; }
  </style>
</head>
<body>
  <!-- SIDEBAR -->
  <div class="sidebar">
      <div class="logo"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['username']) ?></div>
      <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="add_user.php"><i class="fas fa-user-plus"></i> Add User</a>
      <a href="weather_display.php"><i class="fas fa-cloud-sun"></i> Weather</a>
      <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
      <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
      <a href="generate_report.php"><i class="fas fa-file-alt"></i> Report</a>
      <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <!-- MAIN CONTENT -->
  <div class="container">
    <div class="form-box">
      <h2><i class="fas fa-edit"></i> Edit User</h2>
      <?php if (!empty($error)): ?><p class="error"><?= $error ?></p><?php endif; ?>
      <form method="post" onsubmit="return confirmUpdate();">
        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

        <label>New Password (leave blank to keep current)</label>
        <input type="password" name="password">

        <button type="submit" name="update"><i class="fas fa-save"></i> Update</button>
        <a href="admin_dashboard.php" class="cancel-btn"><i class="fas fa-times"></i> Cancel</a>
      </form>
    </div>
  </div>

  <script>
    function confirmUpdate() {
      return confirm("Are you sure you want to update this user?");
    }
  </script>
</body>
</html>
