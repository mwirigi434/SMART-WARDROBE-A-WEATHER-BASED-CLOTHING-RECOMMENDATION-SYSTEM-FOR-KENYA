<?php
require_once 'config.php';

function sendOtpSms($phone, $otp) {
    $url = 'https://' . INFOBIP_BASE_URL . '/sms/2/text/advanced';
    
    $headers = [
        'Authorization: App ' . INFOBIP_API_KEY,
        'Content-Type: application/json',
        'Accept: application/json'
    ];
    
    $message = [
        'destinations' => [['to' => $phone]],
        'from' => INFOBIP_SENDER_ID,
        'text' => "Your Muringene SDA password reset OTP is: $otp. Valid for 5 minutes."
    ];
    
    $payload = json_encode(['messages' => [$message]]);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['success' => false, 'message' => "CURL Error: $error"];
    }
    
    $responseData = json_decode($response, true);
    
    if ($httpCode == 200) {
        return ['success' => true];
    } elseif ($httpCode == 403) {
        return ['success' => false, 'message' => "Authentication failed. Check your API key and permissions."];
    } else {
        $errorMsg = $responseData['requestError']['serviceException']['text'] ?? 'Unknown error';
        return ['success' => false, 'message' => "API Error ($httpCode): $errorMsg"];
    }
}
?>