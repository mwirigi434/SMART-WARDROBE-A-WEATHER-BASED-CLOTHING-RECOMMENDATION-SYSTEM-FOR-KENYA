<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'Liam5641.');
define('DB_NAME', 'wardrobe_db');

// Infobip API Configuration
define('INFOBIP_API_KEY', '3a8092a2f82d5bd701149fffe84b64b2-4d9a6d32-6552-40a9-a1e2-4918911356cc');
define('INFOBIP_BASE_URL', 'rpevlm.api.infobip.com');
define('INFOBIP_SENDER_ID', 'MuringeneSDA');

// Session configuration - must come BEFORE session_start()
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// Enable this only if you're using HTTPS
// ini_set('session.cookie_secure', 1);

// Set session garbage collection parameters
ini_set('session.gc_maxlifetime', 1800); // 30 minutes
ini_set('session.cookie_lifetime', 0); // Until browser closes

// Now start the session only if it hasn't been started already
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Regenerate session ID to prevent session fixation
if (!isset($_SESSION['created'])) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) {
    // Regenerate session ID every 30 minutes
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}
?>