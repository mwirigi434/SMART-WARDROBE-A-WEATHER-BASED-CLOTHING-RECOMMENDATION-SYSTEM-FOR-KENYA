<?php
// Remove duplicate session_start() if already in config
require_once 'include/config.php';  
require_once 'include/db_connection.php';
require_once 'include/sms_functions.php';

$error = '';
$success = '';
$show_otp_form = false;

// Function to normalize Kenyan phone numbers
function normalizePhone($phone) {
    $phone = trim($phone);
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Handle various formats
    if (strlen($phone) == 9 && $phone[0] == '7') {
        // 712345678 -> +254712345678
        return '+254' . $phone;
    } elseif (strlen($phone) == 10 && $phone[0] == '0') {
        // 0712345678 -> +254712345678
        return '+254' . substr($phone, 1);
    } elseif (strlen($phone) == 12 && substr($phone, 0, 3) == '254') {
        // 254712345678 -> +254712345678
        return '+' . $phone;
    } elseif (strlen($phone) == 13 && substr($phone, 0, 4) == '+254') {
        // +254712345678 -> keep as is
        return $phone;
    }
    
    // Return as is for other formats, let validation handle it
    return '+' . $phone;
}

// Handle phone submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['phone'])) {
    $original_phone = trim($_POST['phone']);
    $phone = normalizePhone($original_phone);
    
    // Updated validation to accept both 12 and 13 character formats
    if (!preg_match("/^\+254[1-9]\d{7,8}$/", $phone)) {
        $error = "Invalid phone number format. Use 0712345678 or +254712345678";
    } else {
        // Check in admin table with flexible phone matching
        $sql = "SELECT id, phone FROM admin WHERE REPLACE(REPLACE(phone, '+', ''), ' ', '') = REPLACE(REPLACE(?, '+', ''), ' ', '')";
        $clean_phone = preg_replace('/[^0-9]/', '', $phone);
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $clean_phone);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $db_phone = $row['phone'];
            
            $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $_SESSION['password_reset'] = [
                'phone' => $db_phone, // Use the exact format from database
                'otp' => $otp,
                'attempts' => 0,
                'expires' => time() + 300
            ];
            
            $sendResult = sendOtpSms($db_phone, $otp);
            if ($sendResult['success']) {
                $success = "OTP has been sent to your registered phone number.";
                $show_otp_form = true;
            } else {
                $error = "Failed to send OTP. Try again. Error: " . $sendResult['message'];
            }
        } else {
            $error = "Phone number not found in admin records.";
        }
        $stmt->close();
    }
}

// Handle OTP + reset
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['otp'])) {
    if (!isset($_SESSION['password_reset'])) {
        $error = "Session expired. Please start again.";
        $show_otp_form = false;
    } elseif (time() > $_SESSION['password_reset']['expires']) {
        $error = "OTP expired. Request again.";
        unset($_SESSION['password_reset']);
        $show_otp_form = false;
    } elseif ($_SESSION['password_reset']['attempts'] >= 3) {
        $error = "Max OTP attempts reached.";
        unset($_SESSION['password_reset']);
        $show_otp_form = false;
    } elseif ($_POST['otp'] !== $_SESSION['password_reset']['otp']) {
        $_SESSION['password_reset']['attempts']++;
        $error = "Invalid OTP. Attempts left: " . (3 - $_SESSION['password_reset']['attempts']);
        $show_otp_form = true;
    } elseif ($_POST['new_password'] !== $_POST['confirm_password']) {
        $error = "Passwords do not match.";
        $show_otp_form = true;
    } elseif (strlen($_POST['new_password']) < 6) {
        $error = "Password must be at least 6 characters.";
        $show_otp_form = true;
    } else {
        $phone = $_SESSION['password_reset']['phone'];
        $hashed_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        
        $sql = "UPDATE admin SET password = ? WHERE phone = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $hashed_password, $phone);
        
        if ($stmt->execute()) {
            $_SESSION['reset_success'] = "Password updated successfully. Please login.";
            unset($_SESSION['password_reset']);
            header("Location: login.php");
            exit();
        } else {
            $error = "Failed to update password.";
            $show_otp_form = true;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Password Reset</title>
  <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="container">
  <div class="form-box box">
    <header>ADMIN PASSWORD RESET</header>
    <hr>

    <?php if ($success): ?>
      <div class="message success"><p><?= htmlspecialchars($success) ?></p></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="message error"><p><?= htmlspecialchars($error) ?></p></div>
    <?php endif; ?>

    <?php if (!$show_otp_form && !$success): ?>
      <form method="POST" action="">
        <div class="input-container">
          <i class="fa fa-phone icon"></i>
          <input class="input-field" type="tel" name="phone" placeholder="Enter Phone Number" required>
        </div>
        <input type="submit" value="Send OTP" class="button">
      </form>
    <?php elseif ($show_otp_form): ?>
      <form method="POST" action="">
        <div class="input-container">
          <i class="fa fa-key icon"></i>
          <input class="input-field" type="text" name="otp" placeholder="Enter OTP" required maxlength="6">
        </div>

        <div class="input-container">
          <i class="fa fa-lock icon"></i>
          <input class="input-field" type="password" name="new_password" placeholder="New Password" required>
        </div>

        <div class="input-container">
          <i class="fa fa-lock icon"></i>
          <input class="input-field" type="password" name="confirm_password" placeholder="Confirm Password" required>
        </div>

        <input type="submit" value="Reset Password" class="button">
      </form>
    <?php endif; ?>

    <div class="text-center mt-3">
      <a href="home.php"><i class="fa fa-arrow-left"></i> Back to Login</a>
    </div>
  </div>
</div>
</body>
</html>

<?php 
// Only close connection if it exists
if (isset($conn)) {
    $conn->close();
}
?>