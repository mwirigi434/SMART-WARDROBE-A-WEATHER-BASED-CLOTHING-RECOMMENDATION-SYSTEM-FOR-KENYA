<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Get user details from session
$username = htmlspecialchars($_SESSION['username'] ?? 'User');
$userId = $_SESSION['id'];

// Function to fetch AI recommendations with improved error handling
function fetchClothingRecommendations() {
    // Properly encode the path to handle spaces
    $basePath = dirname($_SERVER['PHP_SELF']);
    $encodedPath = str_replace(' ', '%20', $basePath);
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . $encodedPath . '/callAI.php';
    
    try {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FAILONERROR => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'X-Requested-With: XMLHttpRequest'
            ]
        ]);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            throw new Exception("API connection error: " . curl_error($ch));
        }
        
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpCode !== 200) {
            throw new Exception("API returned HTTP code: $httpCode");
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response");
        }
        
        return $data;
    } catch (Exception $e) {
        error_log("Recommendation fetch error: " . $e->getMessage());
        return [
            'status' => 'error',
            'message' => $e->getMessage(),
            'last_updated' => date('Y-m-d H:i:s'),
            // Fallback recommendations if API fails
            'recommendations' => "**Nairobi**\n\n**Male clothing recommendations:**\n- Casual: Light sweater with jeans\n- Formal: Dress shirt with blazer\n\n**Female clothing recommendations:**\n- Casual: Long-sleeve blouse with leggings\n- Formal: Blouse with dress pants\n\n**Children clothing recommendations:**\n- Casual: Long-sleeve t-shirt with pants\n- Formal: Collared shirt with dress pants",
            'raw_weather_data' => [
                'Nairobi' => [
                    'temperature' => 18,
                    'feels_like' => 17,
                    'humidity' => 65,
                    'description' => 'Cloudy',
                    'wind_speed' => 2.2
                ]
            ]
        ];
    } finally {
        if (isset($ch)) {
            curl_close($ch);
        }
    }
}

// Get recommendations from API
$recommendationsData = fetchClothingRecommendations();

// Function to format recommendations by gender
function formatGenderRecommendations($text, $gender) {
    if (empty($text)) {
        return '<div class="no-recommendations">No recommendations available for ' . htmlspecialchars($gender) . '</div>';
    }

    // Try to find the specific gender section
    $pattern = '/'.preg_quote(ucfirst($gender), '/').' clothing recommendations:(.*?)(?=\n\n\w+ clothing recommendations|$)/is';
    preg_match($pattern, $text, $matches);
    
    $content = $matches[1] ?? $text;
    
    // Format bullet points and line breaks
    $content = preg_replace('/\n\s*-\s*/', "\n• ", $content);
    $content = nl2br(htmlspecialchars(trim($content)));
    $content = preg_replace('/•/', '<i class="fas fa-circle-notch"></i>', $content);
    
    // Add occasion headers if found
    $content = preg_replace('/(Casual|Formal|Business|Smart|Outdoor):/i', '<div class="occasion-header occasion-$1"><strong>$1 Wear:</strong></div>', $content);
    
    return '<div class="recommendation-content">' . $content . '</div>';
}

// Function to get weather icon
function getWeatherIcon($description) {
    $description = strtolower($description ?? '');
    $icons = [
        'sun' => 'fa-sun',
        'clear' => 'fa-sun',
        'cloud' => 'fa-cloud',
        'rain' => 'fa-cloud-rain',
        'thunder' => 'fa-bolt',
        'storm' => 'fa-bolt',
        'snow' => 'fa-snowflake',
        'fog' => 'fa-smog',
        'mist' => 'fa-smog'
    ];
    
    foreach ($icons as $key => $icon) {
        if (strpos($description, $key) !== false) {
            return $icon;
        }
    }
    
    return 'fa-cloud-sun';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clothing Recommendations | Kenya Weather</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3a7bd5;
            --secondary-blue: #00d2ff;
            --male-color: #4a89dc;
            --female-color: #e667af;
            --children-color: #5d9cec;
            --error-color: #f44336;
            --success-color: #4caf50;
            --text-dark: #2c3e50;
            --text-light: #6c757d;
            --bg-light: #f8f9fa;
            --card-shadow: 0 4px 20px rgba(0,0,0,0.08);
            --card-shadow-hover: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            padding-top: 20px;
        }
        
        .user-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--card-shadow);
        }
        
        .user-greeting {
            font-size: 1.25rem;
            font-weight: 500;
        }
        
        .user-greeting i {
            margin-right: 10px;
        }
        
        .nav-tabs {
            border-bottom: none;
        }
        
        .nav-link {
            color: white;
            border: none;
            padding: 8px 15px;
            margin: 0 5px;
            border-radius: 5px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255,255,255,0.2);
            transform: translateY(-2px);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.3);
            font-weight: 600;
        }
        
        .page-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .page-header h1 {
            color: var(--primary-blue);
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .page-header p {
            color: var(--text-light);
            font-size: 1.1rem;
            max-width: 700px;
            margin: 0 auto;
        }
        
        .recommendation-container {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
            margin-bottom: 40px;
        }
        
        .recommendation-box {
            background: white;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
            padding: 30px;
            width: 100%;
            max-width: 350px;
            border-top: 5px solid;
            transition: all 0.3s ease;
        }
        
        .recommendation-box:hover {
            transform: translateY(-5px);
            box-shadow: var(--card-shadow-hover);
        }
        
        .male-box {
            border-top-color: var(--male-color);
        }
        
        .female-box {
            border-top-color: var(--female-color);
        }
        
        .children-box {
            border-top-color: var(--children-color);
        }
        
        .weather-box {
            border-top-color: var(--primary-blue);
            max-width: 800px;
            margin: 0 auto 40px;
        }
        
        .box-title {
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            font-size: 1.3rem;
        }
        
        .box-title i {
            margin-right: 15px;
            font-size: 1.5rem;
        }
        
        .male-box .box-title i {
            color: var(--male-color);
        }
        
        .female-box .box-title i {
            color: var(--female-color);
        }
        
        .children-box .box-title i {
            color: var(--children-color);
        }
        
        .weather-box .box-title i {
            color: var(--primary-blue);
        }
        
        .occasion-header {
            font-weight: 600;
            margin: 20px 0 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #eee;
            color: var(--primary-blue);
        }
        
        .recommendation-item {
            margin-bottom: 12px;
            padding-left: 15px;
            border-left: 3px solid #eee;
            transition: all 0.3s ease;
        }
        
        .male-box .recommendation-item:hover {
            border-left-color: var(--male-color);
        }
        
        .female-box .recommendation-item:hover {
            border-left-color: var(--female-color);
        }
        
        .children-box .recommendation-item:hover {
            border-left-color: var(--children-color);
        }
        
        .recommendation-item i {
            color: #adb5bd;
            font-size: 0.7rem;
            margin-right: 12px;
            transition: all 0.3s ease;
        }
        
        .recommendation-item:hover i {
            color: inherit;
        }
        
        .no-recommendations {
            color: var(--text-light);
            font-style: italic;
        }
        
        .weather-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f1f1f1;
        }
        
        .weather-icon {
            font-size: 1.8rem;
            width: 50px;
            text-align: center;
            margin-right: 20px;
            color: var(--primary-blue);
        }
        
        .city-name {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .weather-stats {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .weather-stat {
            display: flex;
            align-items: center;
        }
        
        .weather-stat i {
            margin-right: 8px;
            color: var(--text-light);
        }
        
        .api-error {
            background-color: #ffebee;
            border-left: 4px solid var(--error-color);
            padding: 15px;
            margin-bottom: 30px;
            border-radius: 4px;
        }
        
        .last-updated {
            font-size: 0.9rem;
            color: var(--text-light);
            margin-top: 20px;
            text-align: right;
        }
        
        .recommendation-content {
            line-height: 1.6;
        }
        
        .recommendation-line {
            margin-bottom: 10px;
        }
        
        /* Popup Modal Styles */
        .recommendation-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .modal-content {
            background: white;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            position: relative;
            transform: translateY(-20px);
            animation: slideUp 0.4s ease forwards;
        }
        
        @keyframes slideUp {
            to { transform: translateY(0); }
        }
        
        .modal-icon {
            font-size: 4rem;
            color: var(--primary-blue);
            margin-bottom: 20px;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .modal-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: var(--primary-blue);
        }
        
        .modal-text {
            font-size: 1.1rem;
            margin-bottom: 30px;
            color: var(--text-dark);
            line-height: 1.6;
        }
        
        .modal-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }
        
        .modal-btn {
            padding: 12px 25px;
            border-radius: 50px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-btn i {
            margin-right: 8px;
        }
        
        .btn-yes {
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            color: white;
        }
        
        .btn-no {
            background-color: #f1f1f1;
            color: var(--text-dark);
        }
        
        .btn-yes:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(58, 123, 213, 0.4);
        }
        
        .btn-no:hover {
            background-color: #e0e0e0;
        }
        
        /* Loading Animation */
        .loading-container {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255,255,255,0.9);
            z-index: 1001;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        
        .loading-spinner {
            width: 70px;
            height: 70px;
            border: 8px solid #f3f3f3;
            border-top: 8px solid var(--primary-blue);
            border-radius: 50%;
            animation: spin 1.5s linear infinite;
            margin-bottom: 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loading-text {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--primary-blue);
            text-align: center;
        }
        
        .loading-dots::after {
            content: '.';
            animation: dots 1.5s steps(5, end) infinite;
        }
        
        @keyframes dots {
            0%, 20% { content: '.'; }
            40% { content: '..'; }
            60% { content: '...'; }
            80%, 100% { content: ''; }
        }

        @media (max-width: 768px) {
            .user-header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .nav-tabs {
                justify-content: center;
            }
            
            .recommendation-box {
                max-width: 100%;
            }

            .modal-content {
                padding: 20px;
            }

            .modal-title {
                font-size: 1.5rem;
            }

            .modal-text {
                font-size: 1rem;
            }

            .modal-buttons {
                flex-direction: column;
                gap: 10px;
            }

            .modal-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- User Header with Navigation -->
        <div class="user-header">
            <div class="user-greeting">
                <i class="fas fa-user-circle"></i>
                Welcome, <?= $username ?>
            </div>
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link" href="search.php"><i class="fas fa-cloud-sun"></i>wether search</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="home.php"><i class="fas fa-tshirt"></i> Clothing Adviser</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php"><i class="fas fa-user-cog"></i> Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <h1><i class="fas fa-tshirt"></i> Clothing Recommendations</h1>
            <p>Personalized suggestions based on current weather conditions in Kenya</p>
        </div>

        <!-- Error Message (if any) -->
        <?php if (isset($recommendationsData['status']) && $recommendationsData['status'] === 'error'): ?>
            <div class="api-error">
                <h4><i class="fas fa-exclamation-triangle"></i> Recommendation Service Unavailable</h4>
                <p><?= htmlspecialchars($recommendationsData['message']) ?></p>
                <p>We're showing basic recommendations. Please try again later.</p>
            </div>
        <?php endif; ?>

        <!-- Weather Summary -->
        <div class="recommendation-box weather-box">
            <div class="box-title">
                <i class="fas <?= getWeatherIcon($recommendationsData['raw_weather_data'][array_key_first($recommendationsData['raw_weather_data'])]['description'] ?? '') ?>"></i>
                <h3>Current Weather Conditions</h3>
            </div>
            <div class="recommendation-content">
                <?php if (!empty($recommendationsData['raw_weather_data'])): ?>
                    <?php foreach ($recommendationsData['raw_weather_data'] as $city => $data): ?>
                        <?php if (!isset($data['error'])): ?>
                            <div class="weather-item">
                                <div class="weather-icon">
                                    <i class="fas <?= getWeatherIcon($data['description']) ?>"></i>
                                </div>
                                <div class="weather-details">
                                    <div class="city-name"><?= htmlspecialchars($city) ?></div>
                                    <div class="weather-stats">
                                        <div class="weather-stat">
                                            <i class="fas fa-temperature-high"></i>
                                            <?= round($data['temperature']) ?>°C
                                        </div>
                                        <div class="weather-stat">
                                            <i class="fas fa-temperature-low"></i>
                                            Feels like <?= round($data['feels_like']) ?>°C
                                        </div>
                                        <div class="weather-stat">
                                            <i class="fas fa-tint"></i>
                                            <?= $data['humidity'] ?>% humidity
                                        </div>
                                        <div class="weather-stat">
                                            <i class="fas fa-wind"></i>
                                            <?= $data['wind_speed'] ?> m/s wind
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-recommendations">Weather data not currently available</div>
                <?php endif; ?>
            </div>
            <?php if (isset($recommendationsData['last_updated'])): ?>
                <div class="last-updated">
                    <i class="fas fa-clock"></i> Updated: <?= htmlspecialchars($recommendationsData['last_updated']) ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Clothing Recommendations -->
        <div class="recommendation-container">
            <!-- Male Recommendations -->
            <div class="recommendation-box male-box">
                <div class="box-title">
                    <i class="fas fa-male"></i>
                    <h3>Men's Clothing</h3>
                </div>
                <div class="recommendation-content">
                    <?= formatGenderRecommendations($recommendationsData['recommendations'] ?? '', 'male') ?>
                </div>
            </div>

            <!-- Female Recommendations -->
            <div class="recommendation-box female-box">
                <div class="box-title">
                    <i class="fas fa-female"></i>
                    <h3>Women's Clothing</h3>
                </div>
                <div class="recommendation-content">
                    <?= formatGenderRecommendations($recommendationsData['recommendations'] ?? '', 'female') ?>
                </div>
            </div>

            <!-- Children Recommendations -->
            <div class="recommendation-box children-box">
                <div class="box-title">
                    <i class="fas fa-child"></i>
                    <h3>Children's Clothing</h3>
                </div>
                <div class="recommendation-content">
                    <?= formatGenderRecommendations($recommendationsData['recommendations'] ?? '', 'children') ?>
                </div>
            </div>
        </div>
    </div>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto-refresh every 15 minutes
    setTimeout(() => {
        window.location.reload();
    }, 900000);
    
    // Add animation to recommendation items
    document.querySelectorAll('.recommendation-item, .recommendation-line').forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'translateX(-10px)';
        item.style.transition = `all 0.3s ease ${index * 0.1}s`;
        
        setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'translateX(0)';
        }, 100);
    });
    
    // Function to show the recommendation popup
    function showRecommendationPopup() {
        // Create the modal if it doesn't exist
        if (!document.getElementById('recommendationModal')) {
            const modalHTML = `
                <div class="recommendation-modal" id="recommendationModal">
                    <div class="modal-content">
                        <div class="modal-icon">
                            <i class="fas fa-magic"></i>
                        </div>
                        <h2 class="modal-title">Generate Outfit Images</h2>
                        <p class="modal-text">Would you like to visualize these clothing recommendations as AI-generated images? We can create beautiful outfit visuals based on the current weather conditions.</p>
                        <div class="modal-buttons">
                            <button class="modal-btn btn-yes" id="generateYes">
                                <i class="fas fa-check"></i> Yes, Generate
                            </button>
                            <button class="modal-btn btn-no" id="generateNo">
                                <i class="fas fa-times"></i> No Thanks
                            </button>
                        </div>
                    </div>
                </div>
                <div class="loading-container" id="loadingContainer">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">Generating beautiful outfit images<span class="loading-dots"></span></div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Add event listeners to buttons
            document.getElementById('generateYes').addEventListener('click', function() {
                // Show loading animation
                document.getElementById('recommendationModal').style.display = 'none';
                document.getElementById('loadingContainer').style.display = 'flex';
                
                // Redirect after a short delay to allow loading animation to show
                setTimeout(function() {
                    window.location.href = 'genimg.php';
                }, 1500);
            });
            
            document.getElementById('generateNo').addEventListener('click', function() {
                // Just hide the modal, don't redirect
                document.getElementById('recommendationModal').style.display = 'none';
                // Show the popup again after 1 second
                setTimeout(showRecommendationPopup, 7000);
            });
        }
        
        // Show the modal
        document.getElementById('recommendationModal').style.display = 'flex';
    }
    
    // Show recommendation popup after content loads
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(showRecommendationPopup, 20000); // Show after 2 seconds
    });
</script>
</body>
</html>