
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>VIBENET Hotspot Template - Index</title>
 <script src="https://cdn.tailwindcss.com"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.0.18/sweetalert2.all.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/glider-js@1.7.7/glider.min.css" />
 <script src="https://cdn.jsdelivr.net/npm/glider-js@1.7.7/glider.min.js"></script>
 <link rel="preconnect" href="https://cdn.jsdelivr.net">
 <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
 <link rel="stylesheet" type="text/css" href="styles.css">
<style>
    .call-icon {
        font-size: 3rem; /* Adjust the size of the icon */
        color: #25D366; /* You can change this to your preferred color */
        border-radius: 40%;
        padding: 15px;
        transition: transform 0.3s ease;
    }
    .call-icon:hover {
        transform: scale(1.1);
    }
</style>
</head>
<body class="font-sans antialiased text-gray-900">
    <!-- Sticky Header -->
    <header class="bg-indigo-900 text-white fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
            <div class="flex items-center justify-between h-16">
                <!-- Logo and title area -->
                <div class="flex items-center">
                    <img src="logo.png" alt="Your Company Logo" class="h-8 w-8 mr-2">
                    <h1 class="text-xl font-bold">VIBENET</h1>
                </div>
                <!-- Navigation Links and Contact Number -->
                <div class="block">
                    <div class="ml-10 flex items-baseline space-x-4">
                        <a href="#alreadyHavePackage" class="text-indigo-200 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Already Paid? Click Here.</a>
                        <span class="text-indigo-200">0793505047</span>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main content -->
    <main class="pt-24">
        <section class="bg-white">
            <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-extrabold text-gray-900 mb-6">We Provide Fast,Cheap and Reliable Wifi Connection Near You.</h2>
                <!-- Pricing Section -->
                <div class="mt-10">
                    <div class="text-center">
                        <h3 class="text-2xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-3xl sm:leading-9">
                            CHECK OUR PRICING
                        </h3>
                        <p class="mt-4 max-w-2xl text-xl leading-7 text-gray-500 lg:mx-auto">
                            Choose a plan that fits your needs.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </main>
<div class="mt-10 max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-5">
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
2 Hours Unlimited
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
10
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
2 Hrs Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="1" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
3-Day Connect
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
100
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
3 Days Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="2" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
35 minutes @ 5bob
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
5
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
35 Mins Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="3" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
3 Hours Unlimited
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
15
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
3 Hrs Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="5" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
6 hours unlimited
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
20
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
6 Hrs Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="6" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
Supper connect 12 hours
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
30
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
12 Hrs Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="7" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
The Weekly Unlimited
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
200
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
7 Days Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="8" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
24 Hours Unlimited data
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
48
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
24 Hrs Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="9" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
    <div class="flex flex-col rounded-lg shadow-xl overflow-hidden transform transition duration-500 hover:scale-105">
        <div class="px-4 py-5 bg-gradient-to-tr from-blue-50 to-blue-200 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-blue-800 text-blue-50">
Monthly plan
            </span>
            <div class="mt-4 text-4xl leading-none font-extrabold text-blue-800">
                <span class="text-lg font-medium text-blue-600">ksh</span>
500
            </div>
            <p class="mt-2 text-md leading-5 text-blue-700 text-center">
1 Months Unlimited
            </p>
        </div>
        <div class="px-4 pt-4 pb-6 bg-blue-500 text-center">
            <a href="#" class="inline-block text-blue-800 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 transform transition duration-150 ease-in-out rounded-lg font-semibold px-3 py-2 text-xs shadow-lg cursor-pointer"
               onclick="handlePhoneNumberSubmission(this.getAttribute('data-plan-id'), this.getAttribute('data-router-id')); return false;" data-plan-id="10" data-router-id="1">
                Click Here To Connect
            </a>
        </div>
    </div>
</div>
<div id="alreadyHavePackage" class="container mx-auto px-4">
    <div class="max-w-md mx-auto bg-white rounded-lg overflow-hidden md:max-w-lg">
        <div class="md:flex">
            <div class="w-full p-5">
                <div class="text-center">
                    <h3 class="text-2xl text-gray-900">Already Have an Active Package?</h3>
                </div>
                <form id="loginForm" class="form" name="login" action="http://vibenet.com/login" method="post" >
                    <input type="hidden" name="dst" value="http://www.msftconnecttest.com/redirect" />
                    <input type="hidden" name="popup" value="true" />
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Username</label>
                        <input id="usernameInput" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="username" type="text" value="" placeholder="Username">
                    </div>
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="password">Password</label>
                        <input id="passwordInput" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline" name="password" type="password" placeholder="******************">
                    </div>
                    <div class="flex items-center justify-between">
                        <button id="submitBtn" class="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="button">
                            Click Here To Connect
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="mt-10 text-center">
    <a href="https://vibenet.ispledger.com/index.php?_route=login" class="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
        Have a voucher code? Click here
    </a>
</div>
<!-- Mpesa Code Section -->
<div id="mpesaCodeSection" class="container mx-auto px-4 mt-8">
    <div class="max-w-md mx-auto bg-white rounded-lg overflow-hidden md:max-w-lg">
        <div class="md:flex">
            <div class="w-full p-5">
                <div class="text-center">
                    <h3 class="text-2xl text-gray-900">Enter Your Mpesa Message</h3>
                </div>
                <form id="mpesaCodeForm">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="mpesa_code">Mpesa Message</label>
                        <textarea id="mpesaCodeInput" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="mpesa_code" rows="4" placeholder="Enter your full Mpesa message"></textarea>
                    </div>
                    <div class="flex items-center justify-between">
                        <button id="mpesaCodeSubmitBtn" class="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="button">
                            Submit Mpesa Message
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    // Suppose we store the current router ID in localStorage when a user selects a plan
    // or if you only have a single router, we can fallback to a router ID from the database:
    var routerId = localStorage.getItem('currentRouterId') || '1';

    document.getElementById('mpesaCodeSubmitBtn').addEventListener('click', function(event) {
        event.preventDefault();

        var mpesaMessage = document.getElementById('mpesaCodeInput').value.trim();
        if (mpesaMessage === '') {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Please enter the Mpesa message.'
            });
            return;
        }

        Swal.fire({
            title: 'Processing Mpesa Message',
            text: 'Please wait while we verify your transaction...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // 1) Send AJAX request to mpesacode.php
        fetch('https://vibenet.ispledger.com/system/mpesacode.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                mpesa_code: mpesaMessage,
                router_id: routerId  // pass the router ID
            }),
        })
        .then(response => response.json())
        .then(data => {
            Swal.close();

            if (data.status === 'success') {
                // The transaction belongs to this router => log in
                var username = data.username;
                Swal.fire({
                    icon: 'success',
                    title: 'Transaction Verified',
                    text: 'Logging you in automatically...',
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    // Autofill the login form
                    document.getElementById('usernameInput').value = username;
                    document.getElementById('passwordInput').value = '1234';

                    // Optionally, show a final success before submitting
                    Swal.fire({
                        icon: 'success',
                        title: 'Logged In',
                        text: 'You have been logged in successfully.',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        // Submit the login form
                        document.getElementById('loginForm').submit();
                    });
                });
            }
            else if (data.status === 'roaming') {
                // 2) The router mismatch was detected => call roaming.php
                Swal.fire({
                    title: 'Roaming in Progress',
                    text: 'Setting up your account on this router. Please wait...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                fetch('https://vibenet.ispledger.com/system/roaming.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        mpesa_code: mpesaMessage,
                        router_id: routerId
                    })
                })
                .then(resp => resp.json())
                .then(roamingData => {
                    Swal.close();
                    if (roamingData.status === 'success') {
                        // The roaming logic created a subscription on the new router
                        var newUsername = roamingData.username;
                        Swal.fire({
                            icon: 'success',
                            title: 'Roaming Completed',
                            text: 'Your plan is now active on this router. Logging you in...',
                            timer: 2000,
                            showConfirmButton: false
                        }).then(() => {
                            // Autofill the login form
                            document.getElementById('usernameInput').value = newUsername;
                            document.getElementById('passwordInput').value = '1234';

                            // Log them in
                            Swal.fire({
                                icon: 'success',
                                title: 'Logged In',
                                text: 'You have been logged in successfully.',
                                timer: 1500,
                                showConfirmButton: false
                            }).then(() => {
                                document.getElementById('loginForm').submit();
                            });
                        });
                    } else {
                        // Some error in roaming
                        Swal.fire({
                            icon: 'error',
                            title: 'Roaming Error',
                            text: roamingData.message || 'Could not complete roaming.'
                        });
                    }
                })
                .catch(err => {
                    Swal.close();
                    Swal.fire({
                        icon: 'error',
                        title: 'Roaming Error',
                        text: 'An error occurred while processing roaming.'
                    });
                    console.error('Roaming Error:', err);
                });
            }
            else {
                // Another error from mpesacode.php
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.message
                });
            }
        })
        .catch(error => {
            // mpesacode.php fetch error
            Swal.close();
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An error occurred while processing your request.'
            });
            console.error('Error:', error);
        });
    });
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    function autofillLogin() {
        var phoneNumber = '2547xxxxxxx';
        var password = '1234';
        document.querySelector('input[name="username"]').value = phoneNumber;
        document.querySelector('input[name="password"]').value = password;
        setTimeout(function() {
            document.querySelector('button[type="submit"]').click();
        }, 15000);
    }
    autofillLogin();
});
</script>
<script>
function toggleFAQ(faqId) {
    var element = document.getElementById(faqId);
    if (element.style.display === "block") {
        element.style.display = "none";
    } else {
        element.style.display = "block";
    }
}
</script>
<form id="loginForm" class="form" name="login" action="http://vibenet.com/login" method="post" >
    <input type="hidden" name="dst" value="http://www.msftconnecttest.com/redirect" />
    <input type="hidden" name="popup" value="true" />
    <input type="hidden" name="mac" value="02:F8:9C:17:25:4F" />
    <!-- Rest of the form code -->
</form>

<!-- Add a container to display the MAC address -->
<div id="macAddressContainer" class="mt-4">
    <p>Your MAC Address: <span id="macAddressDisplay"></span></p>
</div>

<!-- Add a script to retrieve and display the MAC address -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var macAddressInput = document.querySelector('input[name="mac"]');
        var macAddressDisplay = document.getElementById('macAddressDisplay');
        
        if (macAddressInput && macAddressDisplay) {
            var macAddress = macAddressInput.value;
            macAddressDisplay.textContent = macAddress;
        }
    });
</script>
</section>
</main>
<!-- Footer -->
<footer class="bg-indigo-900 text-white">
    <div class="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div class="lg:grid lg:grid-cols-3 lg:gap-8">
            <div class="lg:col-span-1">
                <h2 class="text-sm font-semibold uppercase tracking-wider">
                    Contact Us
                </h2>
                <ul class="mt-4 space-y-4">
                    <li>
                        <span class="block">Address</span>
                    </li>
                    <li>
                        <span class="block">Email: contact@Vibenet </span>
                    </li>
                    <li>
                        <span class="block">Phone: 0793505047</span>
                    </li>
                </ul>
            </div>
            <div class="lg:col-span-1">
                <h2 class="text-sm font-semibold uppercase tracking-wider">
                    Quick Links
                </h2>
                <ul class="mt-4 space-y-4">
                    <li><a href="#" class="hover:underline">About Us</a></li>
                    <li><a href="#" class="hover:underline">Our Services</a></li>
                    <li><a href="#" class="hover:underline">FAQ</a></li>
                    <li><a href="#" class="hover:underline">Support</a></li>
                </ul>
            </div>
            <div class="lg:col-span-1">
                <h2 class="text-sm font-semibold uppercase tracking-wider">
                     Follow Us
                </h2>
                <div class="mt-4 space-x-4">
                    <a href="#" class="hover:text-gray-400"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="hover:text-gray-400"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="hover:text-gray-400"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="hover:text-gray-400"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
        <div class="mt-8 border-t border-gray-700 pt-8 md:flex md:items-center md:justify-between">
            <div class="flex space-x-6 md:order-2">
                <a href="#" class="text-gray-400 hover:text-gray-300"><span class="sr-only">Facebook</span><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="text-gray-400 hover:text-gray-300"><span class="sr-only">Instagram</span><i class="fab fa-instagram"></i></a>
                <a href="#" class="text-gray-400 hover:text-gray-300"><span class="sr-only">Twitter</span><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-gray-400 hover:text-gray-300"><span class="sr-only">LinkedIn</span><i class="fab fa-linkedin-in"></i></a>
            </div>
<p class="mt-8 text-base leading-6 text-gray-400 md:mt-0 md:order-1">
                &copy; 2024 FreeIspRadius. All rights reserved.
            </p>
        </div>
    </div>
<div class="fixed bottom-4 right-4">
    <a href="tel:0793505047" class="call-icon">
        <i class="fas fa-phone"></i>
    </a>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    function formatPhoneNumber(phoneNumber) {
        if (phoneNumber.startsWith('+')) {
            phoneNumber = phoneNumber.substring(1);
        }
        if (phoneNumber.startsWith('0')) {
            phoneNumber = '254' + phoneNumber.substring(1);
        }
        if (phoneNumber.match(/^(7|1)/)) {
            phoneNumber = '254' + phoneNumber;
        }
        return phoneNumber;
    }

    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days*24*60*60*1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "")  + expires + "; path=/";
    }

    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    }

    function handlePhoneNumberSubmission(planId, routerId) {
        Swal.fire({
            title: 'Enter Your Phone Number',
            input: 'text',
            inputPlaceholder: 'Your phone number here',
            inputAttributes: {
                autocapitalize: 'off'
            },
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            backdrop: `
                rgba(0,0,123,0.4)
                url("https://sweetalert2.github.io/images/nyan-cat.gif")
                center left
                no-repeat
            `,
            preConfirm: (phoneNumber) => {
                var formattedPhoneNumber = formatPhoneNumber(phoneNumber);
                var macAddress = document.querySelector('input[name="mac"]').value;
                var lastFourChars = macAddress.slice(-4);
                var username = formattedPhoneNumber + '-' + lastFourChars;
                try {
                    localStorage.setItem('phoneNumber', formattedPhoneNumber);
                    localStorage.setItem('lastFourChars', lastFourChars);
                } catch (e) {
                    setCookie('phoneNumber', formattedPhoneNumber, 1);
                    setCookie('lastFourChars', lastFourChars, 1);
                }
                document.getElementById('usernameInput').value = username;
                console.log("Phone number for autofill:", formattedPhoneNumber);

                return fetch('https://vibenet.ispledger.com/index.php?_route=plugin/CreateHotspotuser&type=grant', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({phone_number: formattedPhoneNumber, plan_id: planId, router_id: routerId, mac_address: lastFourChars}),
                })
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'error') throw new Error(data.message);
                    
                    // Set the expiration time for the paymentSubmitted flag (2 minutes from now)
                    var expirationTime = new Date().getTime() + (1 * 60 * 1000);
                    try {
                        localStorage.setItem('paymentSubmittedExpiration', expirationTime.toString());
                        localStorage.setItem('paymentSubmitted', 'true');
                    } catch (e) {
                        setCookie('paymentSubmittedExpiration', expirationTime.toString(), 1);
                        setCookie('paymentSubmitted', 'true', 1);
                    }
                    
                    // Start confirming payment every three seconds
                    startConfirmingPayment();
                    
                    return formattedPhoneNumber;
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: error.message,
                    });
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        });
    }

    function startConfirmingPayment() {
        var loginInterval = setInterval(function() {
            Swal.fire({
                title: 'Confirming Payment',
                html: 'Please wait while we confirm your payment and log you in...',
                allowOutsideClick: false,
                allowEscapeKey: false,
                allowEnterKey: false,
                showConfirmButton: false,
                onBeforeOpen: () => {
                    Swal.showLoading();
                }
            });
            
            // Attempt to log in by clicking the submit button
            document.getElementById('submitBtn').click();
        }, 3000);
    }

    function refreshData() {
        function refreshDataInternal() {
            var usernameInput = document.getElementById('usernameInput');
            if (usernameInput.value) {
                var phoneNumber = usernameInput.value.split('-')[0];
                $.ajax({
                    url: 'https://vibenet.ispledger.com/index.php?_route=plugin/CreateHotspotuser&type=verify',
                    method: "POST",
                    data: {phone_number: phoneNumber},
                    dataType: "json",
                    success: function(data) {
                        // Response handling code
                        if (data.Resultcode === "3") {
                            // Payment successful and user redirected
                            console.log("Payment successful. Redirecting...");
                            // Perform any necessary actions upon successful payment
                        } else if (data.Resultcode === "2") {
                            // Payment failed or cancelled
                            console.log("Payment failed or cancelled. Error: " + data.Message);
                            // Perform any necessary actions upon payment failure or cancellation
                            // Clear the payment submission flags from localStorage
                            try {
                                localStorage.removeItem('paymentSubmitted');
                                localStorage.removeItem('paymentSubmittedExpiration');
                            } catch (e) {
                                setCookie('paymentSubmitted', '', -1);
                                setCookie('paymentSubmittedExpiration', '', -1);
                            }
                        } else if (data.Resultcode === "1") {
                            // Payment pending
                            console.log("Payment pending. Message: " + data.Message);
                            // Perform any necessary actions while payment is pending
                        } else {
                            // Unknown response code
                            console.log("Unknown response code: " + data.Resultcode);
                        }
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        console.log("Error: " + errorThrown);
                        // Perform any necessary error handling
                    }
                });
            }
        }
        var refreshInterval = setInterval(refreshDataInternal, 2000);
    }

    document.addEventListener('DOMContentLoaded', function() {
        var phoneNumber, lastFourChars;
        try {
            phoneNumber = localStorage.getItem('phoneNumber');
            lastFourChars = localStorage.getItem('lastFourChars');
        } catch (e) {
            phoneNumber = getCookie('phoneNumber');
            lastFourChars = getCookie('lastFourChars');
        }
        if (phoneNumber && lastFourChars) {
            var username = phoneNumber + '-' + lastFourChars;
            document.getElementById('usernameInput').value = username;
        }

        var submitBtn = document.getElementById('submitBtn');
        if (submitBtn) {
            submitBtn.addEventListener('click', function(event) {
                event.preventDefault();
                document.getElementById('loginForm').submit();
            });
        }
        
        // Check if payment has been submitted and if the expiration time has not passed
        var paymentSubmitted, paymentSubmittedExpiration, currentTime;
        try {
            paymentSubmitted = localStorage.getItem('paymentSubmitted');
            paymentSubmittedExpiration = localStorage.getItem('paymentSubmittedExpiration');
            currentTime = new Date().getTime();
        } catch (e) {
            paymentSubmitted = getCookie('paymentSubmitted');
            paymentSubmittedExpiration = getCookie('paymentSubmittedExpiration');
            currentTime = new Date().getTime();
        }
        
        if (paymentSubmitted === 'true' && paymentSubmittedExpiration && currentTime < parseInt(paymentSubmittedExpiration)) {
            // Start confirming payment every three seconds
            startConfirmingPayment();
        } else {
            // Remove the paymentSubmitted and paymentSubmittedExpiration flags from localStorage
            try {
                localStorage.removeItem('paymentSubmitted');
                localStorage.removeItem('paymentSubmittedExpiration');
            } catch (e) {
                setCookie('paymentSubmitted', '', -1);
                setCookie('paymentSubmittedExpiration', '', -1);
            }
        }
    });
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check if the form should attempt to login based on the last submission time
    var lastLoginAttempt = localStorage.getItem('lastLoginAttempt');
    var currentTime = new Date().getTime();

    // Only submit the form if the last attempt was more than 2 minutes ago (120,000 milliseconds)
    if (!lastLoginAttempt || currentTime - lastLoginAttempt > 120000) {
        var loginForm = document.getElementById('loginForm');
        if (loginForm) {
            // Update the timestamp of the last login attempt
            localStorage.setItem('lastLoginAttempt', currentTime);
            // Submit the login form
            loginForm.submit();
        }
    }
});
</script>
