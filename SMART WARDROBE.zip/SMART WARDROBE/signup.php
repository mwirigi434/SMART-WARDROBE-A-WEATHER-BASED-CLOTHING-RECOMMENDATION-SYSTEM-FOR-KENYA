<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: weather_display.php");
    exit();
}

// Clear previous messages
unset($_SESSION['error']);
unset($_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="container">
        <div class="form-box box">
            <?php
            include "connection.php";

            if (isset($_POST['signup'])) {
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $password = $_POST['password'];
                
                // Basic validation
                if (empty($username) || empty($email) || empty($password)) {
                    $error = "All fields are required!";
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = "Invalid email format!";
                } else {
                    // Check if username or email already exists
                    $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
                    $stmt = mysqli_prepare($conn, $check_sql);
                    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    
                    if (mysqli_num_rows($result) > 0) {
                        $error = "Username or email already exists!";
                    } else {
                        // Insert new user (with plain text password - NOT RECOMMENDED)
                        $insert_sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
                        $stmt = mysqli_prepare($conn, $insert_sql);
                        mysqli_stmt_bind_param($stmt, "sss", $username, $email, $password);
                        
                        if (mysqli_stmt_execute($stmt)) {
                            $_SESSION['success'] = "Signup successful! You can now login.";
                            header("Refresh: 3; url=login.php"); // Redirect after 3 seconds
                            echo "<div class='message success'>
                                    <p>".$_SESSION['success']."</p>
                                  </div><br>";
                            exit();
                        } else {
                            $error = "Error creating account: ".mysqli_error($conn);
                        }
                    }
                }
                
                if (isset($error)) {
                    echo "<div class='message error'>
                            <p>$error</p>
                          </div><br>";
                    echo "<a href='signup.php'><button class='btn'>Go Back</button></a>";
                }
            } else {
            ?>
                <header>Signup</header>
                <hr>
                <form action="signup.php" method="POST" autocomplete="off">
                    <div class="form-box">
                        <div class="input-container">
                            <i class="fa fa-user icon"></i>
                            <input class="input-field" type="text" placeholder="Username" name="username" required minlength="3" maxlength="30">
                        </div>

                        <div class="input-container">
                            <i class="fa fa-envelope icon"></i>
                            <input class="input-field" type="email" placeholder="Email Address" name="email" required>
                        </div>

                        <div class="input-container">
                            <i class="fa fa-lock icon"></i>
                            <input class="input-field password" type="password" placeholder="Password" name="password" required minlength="6" autocomplete="new-password">
                            <i class="fa fa-eye toggle icon"></i>
                        </div>
                    </div>

                    <input type="submit" name="signup" id="submit" value="Signup" class="button">

                    <div class="links">
                        Already have an account? <a href="login.php">Login Now</a>
                    </div>
                </form>
            <?php } ?>
        </div>
    </div>

    <script>
        // Toggle password visibility
        const toggle = document.querySelector(".toggle"),
              input = document.querySelector(".password");
        toggle.addEventListener("click", () => {
            if (input.type === "password") {
                input.type = "text";
                toggle.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                input.type = "password";
                toggle.classList.replace("fa-eye-slash", "fa-eye");
            }
        });

        // Prevent form resubmission on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>