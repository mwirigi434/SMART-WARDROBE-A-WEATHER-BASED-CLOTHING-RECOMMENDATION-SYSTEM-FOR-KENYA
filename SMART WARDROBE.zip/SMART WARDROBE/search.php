<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

class WeatherFetcher {
    private $apiKey = '5e3864f214157b0f95954457ebfb9766';
    
    public function getWeatherData($city, $country = '') {
        $location = urlencode($city) . ($country ? ',' . urlencode($country) : '');
        $url = "https://api.openweathermap.org/data/2.5/weather?q={$location}&units=metric&appid={$this->apiKey}";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_FAILONERROR => true
        ]);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($error) {
            throw new Exception("CURL Error: $error");
        }
        
        if ($httpCode !== 200) {
            throw new Exception("API returned HTTP $httpCode");
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response");
        }
        
        return $data;
    }
}

$weatherFetcher = new WeatherFetcher();
$weatherData = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['location'])) {
    $location = trim($_POST['location']);
    try {
        $data = $weatherFetcher->getWeatherData($location);
        
        $weatherData = [
            'city' => $data['name'],
            'country' => $data['sys']['country'] ?? '',
            'temperature' => round($data['main']['temp'], 1),
            'feels_like' => round($data['main']['feels_like'], 1),
            'humidity' => $data['main']['humidity'],
            'weather' => $data['weather'][0]['main'],
            'description' => ucfirst($data['weather'][0]['description']),
            'wind_speed' => round($data['wind']['speed'], 1),
            'icon' => $data['weather'][0]['icon'],
            'timestamp' => date('Y-m-d H:i:s', $data['dt']),
            'pressure' => $data['main']['pressure'],
            'visibility' => isset($data['visibility']) ? round($data['visibility'] / 1000, 1) : 'N/A'
        ];
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather Search</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #4285f4;
            --error-color: #d93025;
            --text-color: #202124;
            --secondary-text: #5f6368;
            --border-color: #dfe1e5;
            --card-bg: #ffffff;
            --page-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Roboto', Arial, sans-serif;
            color: var(--text-color);
            background-color: var(--page-bg);
            margin: 0;
            padding: 0;
            line-height: 1.5;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .user-greeting {
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .user-greeting h4 {
            margin-bottom: 10px;
            color: var(--text-color);
        }
        
        .nav-tabs {
            border-bottom: none;
            display: flex;
            gap: 5px;
        }
        
        .nav-item {
            list-style: none;
        }
        
        .nav-link {
            display: block;
            padding: 8px 15px;
            text-decoration: none;
            color: var(--secondary-text);
            border-radius: 4px;
            transition: all 0.2s;
        }
        
        .nav-link:hover {
            background-color: rgba(66, 133, 244, 0.1);
            color: var(--primary-color);
        }
        
        .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .search-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .search-title {
            color: var(--primary-color);
            font-size: 32px;
            margin-bottom: 20px;
        }
        
        .search-form {
            display: flex;
            max-width: 600px;
            margin: 0 auto;
            box-shadow: 0 2px 5px 1px rgba(64,60,67,.16);
            border-radius: 24px;
            overflow: hidden;
            background: white;
        }
        
        .search-input {
            flex: 1;
            padding: 12px 20px;
            border: none;
            font-size: 16px;
            outline: none;
        }
        
        .search-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0 24px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .search-btn:hover {
            background-color: #3367d6;
        }
        
        .search-results {
            margin-top: 20px;
        }
        
        .result-card {
            background-color: var(--card-bg);
            border-radius: 8px;
            box-shadow: 0 1px 6px rgba(32,33,36,.28);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .result-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .weather-icon {
            width: 60px;
            height: 60px;
            margin-right: 15px;
        }
        
        .location-info {
            flex: 1;
        }
        
        .location-name {
            font-size: 22px;
            font-weight: 500;
            margin: 0;
        }
        
        .location-country {
            color: var(--secondary-text);
            font-size: 16px;
            margin: 4px 0 0;
        }
        
        .weather-temp {
            font-size: 36px;
            font-weight: 400;
            margin: 0;
        }
        
        .weather-desc {
            color: var(--secondary-text);
            margin: 5px 0 0;
            text-transform: capitalize;
        }
        
        .weather-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .detail-item {
            padding: 10px;
            border-radius: 4px;
            background-color: rgba(66,133,244,0.1);
        }
        
        .detail-label {
            font-size: 14px;
            color: var(--secondary-text);
        }
        
        .detail-value {
            font-size: 18px;
            font-weight: 500;
            margin-top: 5px;
        }
        
        .timestamp {
            font-size: 14px;
            color: var(--secondary-text);
            margin-top: 15px;
            text-align: right;
        }
        
        .error-card {
            background-color: #fce8e6;
            border: 1px solid var(--error-color);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .error-title {
            color: var(--error-color);
            font-size: 18px;
            margin-top: 0;
        }
        
        .loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(255,255,255,0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }
        
        .loading-screen.active {
            opacity: 1;
            visibility: visible;
        }
        
        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loading-text {
            margin-top: 15px;
            color: var(--secondary-text);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="user-greeting">
            <h4>Hello <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest' ?>, today's weather data:</h4>
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="weather_display.php"><i class="fas fa-cloud-sun me-1"></i> Weather</a>
                   
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cloth.php" id="clothTab"><i class="fas fa-tshirt me-1"></i> Cloth</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="home.php" id="clothTab"><i class="fas fa-tshirt me-1"></i>Cloth Adviser</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php"><i class="fas fa-user me-1"></i> Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
                </li>
            </ul>
        </div>
        
        <div class="search-header">
            <h1 class="search-title">Weather Search</h1>
            <form class="search-form" method="post">
                <input type="text" name="location" class="search-input" placeholder="Enter city name (e.g. Meru,Mombasa" required value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>">
                <button type="submit" class="search-btn">Search</button>
            </form>
        </div>
        
        <div class="search-results">
            <?php if ($error): ?>
                <div class="error-card">
                    <h2 class="error-title">Error</h2>
                    <p><?php echo htmlspecialchars($error); ?></p>
                    <p>Please try another location.</p>
                </div>
            <?php endif; ?>
            
            <?php if ($weatherData): ?>
                <div class="result-card">
                    <div class="result-header">
                        <img src="https://openweathermap.org/img/wn/<?php echo htmlspecialchars($weatherData['icon']); ?>@2x.png" alt="Weather icon" class="weather-icon">
                        <div class="location-info">
                            <h2 class="location-name"><?php echo htmlspecialchars($weatherData['city']); ?></h2>
                            <?php if ($weatherData['country']): ?>
                                <p class="location-country"><?php echo htmlspecialchars($weatherData['country']); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="temp-info">
                            <p class="weather-temp"><?php echo htmlspecialchars($weatherData['temperature']); ?>°C</p>
                            <p class="weather-desc"><?php echo htmlspecialchars($weatherData['description']); ?></p>
                        </div>
                    </div>
                    
                    <div class="weather-details">
                        <div class="detail-item">
                            <div class="detail-label">Feels Like</div>
                            <div class="detail-value"><?php echo htmlspecialchars($weatherData['feels_like']); ?>°C</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Humidity</div>
                            <div class="detail-value"><?php echo htmlspecialchars($weatherData['humidity']); ?>%</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Wind Speed</div>
                            <div class="detail-value"><?php echo htmlspecialchars($weatherData['wind_speed']); ?> m/s</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Pressure</div>
                            <div class="detail-value"><?php echo htmlspecialchars($weatherData['pressure']); ?> hPa</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Visibility</div>
                            <div class="detail-value"><?php echo htmlspecialchars($weatherData['visibility']); ?> km</div>
                        </div>
                    </div>
                    
                    <p class="timestamp">Last updated: <?php echo htmlspecialchars($weatherData['timestamp']); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="loading-screen" id="loadingScreen">
        <div class="loading-spinner"></div>
        <div class="loading-text">Getting weather data...</div>
    </div>
    
    <script>
        // Show loading screen when form is submitted
        document.querySelector('.search-form').addEventListener('submit', function() {
            document.getElementById('loadingScreen').classList.add('active');
        });
        
        // Hide loading screen when page finishes loading
        window.addEventListener('load', function() {
            document.getElementById('loadingScreen').classList.remove('active');
        });
    </script>
</body>
</html>